﻿#include "widget.h"
#include "ui_widget.h"
#include <pthread.h>

#include <QThread>

#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QJsonObject>
#include <QJsonDocument>
#include <QUrl>
#include <QString>
#include <QFileDialog>
#include <QTimerEvent>

#define REFRESH_TRANSTASK_STATUS_TIMER 	1
#define REFRESH_SPEAKVOLUME_TIMER	    2
#define REFRESH_AUDIOBITRATE_TIMER		3
#define REFRESH_VIDEOBITRATE_TIMER		4
#define REFRESH_RECORDSTATE_TIMER	    5

#define MAX_SIGN_LEN 100
Widget* pthis;

typedef struct login_info_struct
{
    char sign[MAX_SIGN_LEN];
    int  ts;
    int  err;
}LOGIN_INFO,*LPLOGIN_INFO;

static int g_sOpenedCamUserId=0;
LOGIN_INFO *g_login_info;

//http request
void Widget::request_sign(QString server_url,
                          QString appid,
                          QString userid)
{
    QNetworkRequest http_request;
    http_request.setUrl(QUrl(server_url));
    QString head_appid("appid=");
    QString head_userid("userid=");
    QString head_strUserid("strUserid=");
    QString str_userid_value("");
    QString head_add("&");

    QString content_data=head_appid + appid + head_add + head_userid + userid + head_add + head_strUserid + str_userid_value;
    QByteArray content_string = content_data.toUtf8();

    printf("json >> %s\n",content_data.toStdString().c_str());
    qDebug()<<"http<post>:"<< content_data.toStdString().c_str();

    http_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    QByteArray post_data_sz = QByteArray::number(content_string.size());
    http_request.setRawHeader("Content-Length",post_data_sz);

    connect(m_http_manager,SIGNAL(finished(QNetworkReply*)),
            this,SLOT(response_callback(QNetworkReply*)));

    m_http_manager->post(http_request, content_string);
}

void Widget::timerEvent(QTimerEvent *event)
{
    if(event->timerId()==m_iTranstimerid)
        TimerProc_CallBack(this,0,REFRESH_TRANSTASK_STATUS_TIMER,0);
    else if(event->timerId()==m_ispeakvolumetimerid)
        TimerProc_CallBack(this,0,REFRESH_SPEAKVOLUME_TIMER, 0);
    else if(event->timerId()==m_iaudiobitratetimerid)
        TimerProc_CallBack(this,0,REFRESH_AUDIOBITRATE_TIMER, 0);
    else if(event->timerId()==m_ivideobitratetimerid)
        TimerProc_CallBack(this,0,REFRESH_VIDEOBITRATE_TIMER, 0);

}

//http response
void Widget::response_callback(QNetworkReply* http_reply)
{
    if(http_reply->error() != QNetworkReply::NoError)
    {
        AppendLogString("http conect error");
        qDebug() << "Error:" << http_reply->errorString();
        printf("post error\n");
        qDebug()<<"post error";
        return;
    }

    QByteArray recv_data = http_reply->readAll();

    QJsonParseError json_error;
    QJsonDocument parse_doucment = QJsonDocument::fromJson(recv_data, &json_error);
    if(json_error.error == QJsonParseError::NoError)
    {
        if(parse_doucment.isObject())
        {
            QJsonObject obj = parse_doucment.object();
            if(obj.contains("errorcode"))
            {
                QJsonValue error_value = obj.take("errorcode");
                if(error_value.isDouble())
                {
                    pthis->m_sign_err = error_value.toInt();
                    qDebug()<<"#debug# error:"<<pthis->m_sign_err;
                }
            }
            if(obj.contains("timestamp"))
            {
                QJsonValue timestamp_value = obj.take("timestamp");
                if(timestamp_value.isDouble())
                {
                    pthis->m_sign_ts = timestamp_value.toVariant().toInt();
                    qDebug()<<"#debug# timestamp:"<<pthis->m_sign_ts;
                }
            }
            if(obj.contains("sigStr"))
            {
                QJsonValue sigStr_value = obj.take("sigStr");
                if(sigStr_value.isString())
                {
                    QString sigStr = sigStr_value.toString();
                    m_qsign_data = sigStr_value.toString();

                    memset(pthis->m_sign_data,'\0',256);
                    memcpy(pthis->m_sign_data, sigStr.toStdString().c_str(),sigStr.toStdString().size());

                    //login to server
                    if(pthis->m_sign_err == 0)
                    {
                        QString serveraddr = ui->ServerAddrlineEdit->text();
                        QString serverport = ui->ServerPortlineEdit->text();
                        QString username = ui->UserNamelineEdit->text();
                        BRAC_Connect(serveraddr.toStdString().c_str(), serverport.toInt());
                        QString str_appid = ui->Appid_lineEdit->text();
                        QByteArray ba = m_qsign_data.toLatin1();
                        char *pSign = ba.data();

                        BRAC_LoginEx(username.toStdString().c_str(), 33, 0, str_appid.toStdString().c_str(), pthis->m_sign_ts, pSign);
                        QString roomId = ui->RoomId_lineEdit->text();
                        QString pwd = "";
                        BRAC_EnterRoom(roomId.toInt(), (LPCTSTR)pwd.toStdString().c_str(), 0);
                    }
                }
            }
        }
    }

    http_reply->deleteLater();
}

Widget::Widget(QWidget *parent) :
        QWidget(parent),
        ui(new Ui::Widget)
{
    ui->setupUi(this);
    m_http_manager = new QNetworkAccessManager(this);
    int width = this->geometry().width();
    int height = this->geometry().height();
    this->setFixedSize(width,height);

    pthis = this;

    //pthis->setWindowIcon(QIcon("AnyChatVideoMixer.ico"));

    m_strLogInfo = "";
    m_lpLocalVideoFrame = NULL;
    m_iLocalVideoSize = 0;
    m_lpRemoteVideoFrame = NULL;
    m_iRemoteVideoSize = 0;
    m_dwTransTaskId=-1;
    ui->RemoteUserlabel->setStyleSheet("background-color:black");
    ui->LocalUserlabel->setStyleSheet ("background-color:black");
    ui->RoomId_lineEdit->setText("1");
    ui->Appid_lineEdit->setText("fbe957d1-c25a-4992-9e75-d993294a5d56");
    ui->ServerAddrlineEdit->setText("demo.anychat.cn");
    ui->ServerPortlineEdit->setText("8906");

    connect(this,SIGNAL(changeSysLogs(QString)),this,SLOT(setSysLogs(QString)));

    memset(m_iUserID,-1,sizeof(m_iUserID));

    m_isLogin     = false;
    SdlPlayer::SdlInit();
}

Widget::~Widget()
{
    if(m_http_manager)
        delete m_http_manager;

    if(m_lpLocalVideoFrame)
    {
        free(m_lpLocalVideoFrame);
        m_lpLocalVideoFrame = NULL;
    }

    if(m_lpRemoteVideoFrame)
    {
        free(m_lpRemoteVideoFrame);
        m_lpRemoteVideoFrame = NULL;
    }
    killTimer(m_ispeakvolumetimerid);
    killTimer(m_iaudiobitratetimerid);
    killTimer(m_ivideobitratetimerid);
    delete ui;
    SdlPlayer::SdlRelease();
}

void Widget::closeEvent(QCloseEvent *event)
{
    //BRAC_Logout();
    BRAC_Release();
    event->accept();
}

void Widget::HelloChatRefreshUserList()
{
    ui->UserlistWidget->clear();
    memset(m_iUserID,-1,sizeof(MAX_USER_NUM));

    DWORD dwUserNum = 0;
    BRAC_GetOnlineUser(NULL, dwUserNum);
    if(!dwUserNum)
        return ;
    if (dwUserNum > MAX_USER_NUM)
        return;

    LPDWORD lpdwUserList = (LPDWORD)malloc(sizeof(DWORD) * dwUserNum);
    if (NULL == lpdwUserList)
        return;
    BRAC_GetOnlineUser(lpdwUserList, dwUserNum);

    for(int i = 0; i < (INT)dwUserNum; i++)
    {
        DWORD dwUserID = lpdwUserList[i];

        if(dwUserID != -1)
        {
            char cUserName[120];
            BRAC_GetUserName(dwUserID,(TCHAR*)cUserName,sizeof(cUserName));

            m_iUserID[i] = dwUserID;
            ui->UserlistWidget->insertItem(i,cUserName);
        }
        else
            break;
    }
    free(lpdwUserList);
    /*************/
    lpdwUserList = NULL;
}

void Widget::setSysLogs(QString str)
{
    m_strLogInfo += (str + "\r\n");
    ui->SysMsgTextEdit->setText(m_strLogInfo);
    ui->SysMsgTextEdit->moveCursor(QTextCursor::End);
}
// 透明通道数据扩展回调函数定义
void CALLBACK Widget::TransBufferEx_CallBack(DWORD dwUserid, LPBYTE lpBuf, DWORD dwLen, DWORD wParam, DWORD lParam, DWORD dwTaskId, LPVOID lpUserValue)
{
    Widget *pDemoDlg = (Widget*)lpUserValue;
    if(pDemoDlg)
    {
        BOOL bSuccess = FALSE;
        if(dwLen > 1000)
        {
            bSuccess = lpBuf[1000] == 'Y' ? TRUE : FALSE;
        }
        QString strNotify;
        strNotify.sprintf("TransBuffer_CallBack:dwUserid-%d, bufSize-%d",dwUserid,dwLen,bSuccess ? "Success" : "Fail");
        emit  pDemoDlg->changeSysLogs(strNotify);
    }
}

// 透明通道数据回调函数定义
void CALLBACK Widget::TransBuffer_CallBack(DWORD dwUserid, LPBYTE lpBuf, DWORD dwLen, LPVOID lpUserValue)
{
    Widget *pDemoDlg = (Widget*)lpUserValue;
    if(pDemoDlg)
    {
        QString strNotify;
        strNotify.sprintf("TransBuffer_CallBack:dwUserid-%d, bufSize-%d",dwUserid,dwLen);
        emit  pDemoDlg->changeSysLogs(strNotify);
    }
}

// 文件传输回调函数定义
void CALLBACK Widget::TransFile_CallBack(DWORD dwUserid, LPCTSTR lpFileName, LPCTSTR lpTempFilePath, DWORD dwFileLength, DWORD wParam, DWORD lParam, DWORD dwTaskId, LPVOID lpUserValue)
{
    Widget *pDemoDlg = (Widget*)lpUserValue;
    if(pDemoDlg)
    {
        QString strNotify;
        strNotify.sprintf("TransFile_CallBack:dwUserid-%d, lpFileName-%s, lpTempFilePath-%s",dwUserid,lpFileName,lpTempFilePath);
        emit  pDemoDlg->changeSysLogs(strNotify);

    }
}

// 录像、快照任务完成回调函数定义
void CALLBACK Widget::RecordSnapShot_CallBack(DWORD dwUserid, LPCTSTR lpFileName, DWORD dwParam, BOOL bRecordType, LPVOID lpUserValue)
{
    Widget *pDemoDlg = (Widget*)lpUserValue;
    if(pDemoDlg)
    {
        QString strNotify;
        strNotify.sprintf("%s CallBack:dwUserid-%d, FilePathName-%s",bRecordType?"Record":"SnapShot",(int)dwUserid,lpFileName);
        emit  pDemoDlg->changeSysLogs(strNotify);
    }
}

// SDK Filter 通信数据回调函数定义
void CALLBACK Widget::SDKFilterData_CallBack(LPBYTE lpBuf, DWORD dwLen, LPVOID lpUserValue)
{
    Widget *pDemoDlg = (Widget*)lpUserValue;
    if(pDemoDlg)
    {
        QString strNotify;
        strNotify.sprintf("SDK Filter CallBack:%s",lpBuf);
        emit  pDemoDlg->changeSysLogs(strNotify);
    }
}

void Widget::HelloChatInit()
{
    printf("HelloChatInit \r\n");

    //获取SDK的版本信息
    DWORD dwMainVer,dwSubVer;
    TCHAR szCompileTime[100] = {0};
    BRAC_GetSDKVersion(dwMainVer, dwSubVer, (TCHAR*)szCompileTime, sizeof(szCompileTime));

    QString logstr;
    logstr.sprintf("#INFO# AnyChat Core SDK Version:%d.%d(%s)",dwMainVer,dwSubVer,szCompileTime);
    AppendLogString(logstr);  //调用AppendLogString函数在textEdit中显示当前SDK的版本信息

    //打开（关闭）SDK的日志记录功能
    BRAC_ActiveCallLog(true);


    //设置SDK核心组件所在目录（注：demo程序只是设置为当前目录，项目中需要设置为实际路径）
    QString szCoreSDKPath;
    szCoreSDKPath = QCoreApplication::applicationDirPath();
    (strrchr((char*)szCoreSDKPath.toStdString().c_str(),'/'))[1] = 0;
    BRAC_SetSDKOption(BRAC_SO_CORESDK_PATH,(char*)szCoreSDKPath.toStdString().c_str(),strlen((char*)szCoreSDKPath.toStdString().c_str()));
    // 根据BRAC_InitSDK的第二个参数：dwFuncMode，来告诉SDK该如何处理相关的任务（详情请参考开发文档）
    DWORD dwFuncMode = BRAC_FUNC_VIDEO_CBDATA|BRAC_FUNC_AUDIO_CBDATA|/*BRAC_FUNC_VIDEO_AUTODISP |*/ BRAC_FUNC_AUDIO_AUTOPLAY | BRAC_FUNC_CHKDEPENDMODULE |
                    BRAC_FUNC_AUDIO_VOLUMECALC | BRAC_FUNC_NET_SUPPORTUPNP | BRAC_FUNC_FIREWALL_OPEN |
                    BRAC_FUNC_AUDIO_AUTOVOLUME | BRAC_FUNC_AUDIO_VOLUMECALC | BRAC_FUNC_CONFIG_LOCALINI;
    BRAC_InitSDK((HWND)this->winId(), dwFuncMode);
    BRAC_SetVideoDataExCallBack(BRAC_PIX_FMT_YUV420P,VideoData_CallBackEx,this);
    BRAC_SetAudioDataExCallBack(AudioData_CallBackEx,this);
    BRAC_SetNotifyMessageCallBack(NotifyMessage_CallBack,this);
    BRAC_SetTextMessageCallBack(TextMessage_CallBack,this);
    BRAC_SetTransBufferExCallBack(TransBufferEx_CallBack,this);
    BRAC_SetTransBufferCallBack(TransBuffer_CallBack,this);
    BRAC_SetTransFileCallBack(TransFile_CallBack,this);
    BRAC_SetSDKFilterDataCallBack(SDKFilterData_CallBack,this);
    BRAC_SetCallBack(BRAC_CBTYPE_STREAMRECORD,(void*)RecordSnapShot_CallBack, this);

    m_bEnableVAD = ui->VADcheckBox->isChecked();   //获得四个复选框的值
    m_bEnableAGC = ui->AGCcheckBox->isChecked();
    m_bEnableEcho = ui->AECcheckBox->isChecked();
    m_bEnableNS = ui->NScheckBox->isChecked();

    BRAC_SetSDKOption(BRAC_SO_AUDIO_AGCCTRL,(PCHAR)&m_bEnableAGC,sizeof(m_bEnableAGC));
    BRAC_SetSDKOption(BRAC_SO_AUDIO_VADCTRL,(PCHAR)&m_bEnableVAD,sizeof(m_bEnableVAD));
    BRAC_SetSDKOption(BRAC_SO_AUDIO_NSCTRL,(PCHAR)&m_bEnableNS,sizeof(m_bEnableNS));
    BRAC_SetSDKOption(BRAC_SO_AUDIO_ECHOCTRL,(PCHAR)&m_bEnableEcho,sizeof(m_bEnableEcho));

    DWORD dwP2PPolitic = 0;
    BRAC_SetSDKOption(BRAC_SO_NETWORK_P2PPOLITIC,(const char*)&dwP2PPolitic,sizeof(DWORD));

    DWORD dwVolume = 0;
    BRAC_AudioGetVolume(BRAC_AD_WAVEOUT,dwVolume);
    ui->wavhorizontalSlider->setSliderPosition(dwVolume);//设置滑块位置
    dwVolume = 0;
    BRAC_AudioGetVolume(BRAC_AD_WAVEIN,dwVolume);
    ui->michorizontalSlider->setSliderPosition(dwVolume);

    // 设置录像临时文件保存路径
    QString szRecordDirectory;
    szRecordDirectory = QCoreApplication::applicationDirPath();   //获取当前就用程序路径
    (strrchr((char*)szRecordDirectory.toStdString().c_str(),'/'))[1] = 0;
    szRecordDirectory.append("/Record");
    BRAC_SetSDKOption(BRAC_SO_RECORD_TMPDIR, (char*)szRecordDirectory.toStdString().c_str(), strlen((char*)szRecordDirectory.toStdString().c_str()));

    // 设置录像文件质量参数
    DWORD dwVideoBitrate = 200 * 1000;	// 200kbps
    BRAC_SetSDKOption(BRAC_SO_RECORD_VIDEOBR,(PCHAR)&dwVideoBitrate,sizeof(DWORD));
    DWORD dwAudioBitrate = 96 * 1000;	// 96kbps
    BRAC_SetSDKOption(BRAC_SO_RECORD_AUDIOBR,(PCHAR)&dwAudioBitrate,sizeof(DWORD));

    // 设置快照临时文件保存路径
    QString szSnapShotDirectory;
    szSnapShotDirectory = QCoreApplication::applicationDirPath();   //获取当前应用程序路径
    (strrchr((char*)szSnapShotDirectory.toStdString().c_str(),'/'))[1] = 0;
    szSnapShotDirectory.append("/SnapShot");
    BRAC_SetSDKOption(BRAC_SO_SNAPSHOT_TMPDIR, (char*)szSnapShotDirectory.toStdString().c_str(), strlen((char*)szSnapShotDirectory.toStdString().c_str()));

    // 设置SDK临时文件路径
    QString szTempPath;
    szTempPath = QCoreApplication::applicationDirPath();   //获取当前就用程序路径
    (strrchr((char*)szTempPath.toStdString().c_str(),'/'))[1] = 0;
    szTempPath.append("/SnapShot");
    BRAC_SetSDKOption(BRAC_SO_CORESDK_TMPDIR, (char*)szTempPath.toStdString().c_str(), strlen((char*)szTempPath.toStdString().c_str()));

    // 设置服务器认证密码
    QString pwd = "BaiRuiTech";
    BRAC_SetServerAuthPass((LPCTSTR)pwd.toStdString().c_str());
    m_iaudiobitratetimerid=startTimer(100);
    m_ivideobitratetimerid=startTimer(100);
    m_ispeakvolumetimerid=startTimer(100);
    m_LocalUser.setRect(30, 390, 202, 181);
    m_RemoteUser.setRect(280, 10, 512, 361);
}

void Widget::HelloChatLogin()
{
    //appid 登陆
    if(ui->Appid_checkBox->isChecked() && !ui->Appid_lineEdit->text().isEmpty())
    {
        QString server_url = "http://demo.anychat.cn:8930";
        QString appid_content = ui->Appid_lineEdit->text();
        QString userid = "33";
        request_sign(server_url, appid_content, userid);
    }
    else
    {
        QString serveraddr = ui->ServerAddrlineEdit->text();
        QString serverport = ui->ServerPortlineEdit->text();
        QString username = ui->UserNamelineEdit->text();
        BRAC_Connect(serveraddr.toStdString().c_str(), serverport.toInt());
        BRAC_Login(username.toStdString().c_str(), "", 0);
        QString roomId = ui->RoomId_lineEdit->text();
        QString pwd = "";
        BRAC_EnterRoom(roomId.toInt(), pwd.toStdString().c_str(), 0);
    }
}

void Widget::AppendLogString(QString logstr)
{
    m_strLogInfo += (logstr + "\r\n");
    ui->SysMsgTextEdit->setText(m_strLogInfo);
    ui->SysMsgTextEdit->moveCursor(QTextCursor::End);
}

long Widget::OnGVClientConnect(WPARAM wParam, LPARAM lParam)
{
    bool bSuccess = (bool)wParam;
    QString str(bSuccess ? "#INFO# Connect to server OK" : "#INFO# Connect to Server error");
    emit changeSysLogs(str);

    return 0;
}

long Widget::OnGVClientLogin(WPARAM wParam, LPARAM lParam)
{
    QString logstr;
    DWORD dwUserID = wParam;
    if(lParam == 0)
    {
        CHAR username[120];
        BRAC_GetUserName(dwUserID,(TCHAR*)username,sizeof(username));
        logstr.sprintf("#INFO# Login Server OK UserId %d(%s)", dwUserID, username);

        m_SelfId= dwUserID;

        m_isLogin = true;
        ui->Login_btn->setText("Logout");
    }
    else
        logstr.sprintf("#INFO# Login  Server Error  %d ", lParam);

    emit changeSysLogs(logstr);

    return 0;
}

long Widget::OnGVClientEnterRoom(WPARAM wParam, LPARAM lParam)
{
    QString logstr;
    int roomid = (int)wParam;

    if(lParam == 0)
    {
        logstr.sprintf("#INFO# Success enter room %d,user %d",roomid, m_SelfId);
        BRAC_SetVideoPos(-1, (HWND)this->winId(), m_LocalUser.left(), m_LocalUser.top(), m_LocalUser.right(), m_LocalUser.bottom());

        //Open Local Camera
       BRAC_UserCameraControl(-1, TRUE);
       BRAC_UserSpeakControl(-1, TRUE);

    }
    else
    {
        logstr.sprintf("#INFO# Can not enter room Error code  %d ",lParam);
    }

    emit changeSysLogs(logstr);
    return 0;
}

long Widget::OnGVClientOnlineUser(WPARAM wParam, LPARAM lParam)
{
    QString logstr;
    int onlinenum = (int)wParam;
    logstr.sprintf("#INFO# The room id %d,onlinenum %d",lParam,onlinenum);
    emit changeSysLogs(logstr);
    HelloChatRefreshUserList();

    return 0;
}

long Widget::OnGVClientMicStateChange(WPARAM wParam, LPARAM lParam)
{
    QString logstr;
    logstr.sprintf("#INFO# User id %d ", wParam);
    logstr.append( lParam ? "open":"close");
    logstr.append(" Local Mic Device");

    emit changeSysLogs(logstr);
    return 0;
}

long Widget::OnGVClientUserAtRoom(WPARAM wParam, LPARAM lParam)
{
    QString logstr;
    int userid = (int)wParam;
    bool bEnter = (bool)lParam;

    char username[120] = {0};
    BRAC_GetUserName(userid, (TCHAR*)username, sizeof(username));
    logstr.sprintf("#INFO# User id %d ,User name(%s) ", userid, username);
    logstr.append(bEnter ? "Enter" : "Leave");
    logstr.append("Room");
    emit changeSysLogs(logstr);

    if(bEnter)
    {
        HelloChatRefreshUserList();
    }
    else
    {
        HelloChatRefreshUserList();

        if(g_sOpenedCamUserId == userid)
        {
            BRAC_UserCameraControl(g_sOpenedCamUserId,FALSE);
            BRAC_UserSpeakControl (g_sOpenedCamUserId,FALSE);
            g_sOpenedCamUserId = 0;

            ui->RemoteUserlabel->clear();
            ui->RemoteUserlabel->setText("RemoteUser");
        }
    }
    return 0;
}

long Widget::OnGVClientLinkClose(WPARAM wParam, LPARAM lParam)
{
    emit changeSysLogs("Network disconnect");
    for(INT i = 0; i < MAX_USER_NUM; i++)
    {
        m_iUserID[i] = -1;
        ui->UserlistWidget->takeItem(i);
    }
    return 0;
}

void CALLBACK Widget::TimerProc_CallBack(void* user, UINT uMsg, UINT nIDEvent, DWORD dwTime)
{
    Widget* pwidget =(Widget*)user;
    switch(nIDEvent)
    {
    case REFRESH_TRANSTASK_STATUS_TIMER:
    {
        if(pwidget->m_dwTransTaskId == -1)
        {
            pwidget->killTimer(pwidget->m_iTranstimerid);
            break;
        }
        DWORD ret;
        DWORD dwStatus = 0;
        ret =BRAC_QueryTransTaskInfo(-1, pwidget->m_dwTransTaskId,BRAC_TRANSTASK_STATUS,(PCHAR)&dwStatus,sizeof(DWORD));
        if(ret != GV_ERR_SUCCESS)
        {
            pwidget->m_dwTransTaskId = -1;
            pwidget->ui->fileStatuslabel->setText("");
            if(ret == GV_ERR_TRANSBUF_NOTASK)
                pwidget->AppendLogString("传输任务不在在，可能对方已离开房间！");
            else
                pwidget-> AppendLogString("查询任务信息失败！");
            break;
        }
        double dbProgress = 0.0;
        BRAC_QueryTransTaskInfo(-1,pwidget->m_dwTransTaskId,BRAC_TRANSTASK_PROGRESS,(PCHAR)&dbProgress,sizeof(DOUBLE));
        DWORD dwBitrate  = 0;
        BRAC_QueryTransTaskInfo(-1,pwidget->m_dwTransTaskId,BRAC_TRANSTASK_BITRATE,(PCHAR)&dwBitrate,sizeof(DWORD));

        QString strStatus;
        switch(dwStatus)
        {
        case 1:		strStatus = "Ready";        break;
        case 2:		strStatus = "Process";      break;
        case 3:		strStatus = "Finish";       break;
        case 4:		strStatus = "Cancel";       break;
        case 5:		strStatus = "Reject";       break;
        default:            strStatus = "Unkonw";       break;
        }
        if(dwStatus == 3)           //finish
        {
            pwidget->m_dwTransTaskId = -1;
            pwidget->AppendLogString("传输任务已完成！");
        }
        QString strBitrate;
        if(dwBitrate >= 1000 * 1000)
            strBitrate.sprintf("%.2f Mbps",(float)dwBitrate/1000/1000);
        else if(dwBitrate >= 1000)
            strBitrate.sprintf("%.2f Kbps",(float)dwBitrate/1000);
        else
            strBitrate.sprintf("%.2f bps",(float)dwBitrate);

        QString strNotify;
        strNotify.sprintf("-%.2f%-", dbProgress);
        pwidget->ui->fileStatuslabel->setText(strStatus + strNotify + strBitrate);   //QString类型的能相加表示合并
    }
        break;
    case  REFRESH_SPEAKVOLUME_TIMER:
    {
        double fSpeakVolume = 0.0;
        if( pwidget->m_SelfId != -1 && BRAC_QueryUserState(pwidget->m_SelfId, BRAC_USERSTATE_SPEAKVOLUME,(PCHAR)&fSpeakVolume, sizeof(DOUBLE)) == GV_ERR_SUCCESS)
        {
            pwidget->ui->LocalUserProgressBar->setValue((INT)fSpeakVolume);
        }
        else
        {
            pwidget->ui->LocalUserProgressBar->setValue(0);
        }

        fSpeakVolume = 0.0;
        if(g_sOpenedCamUserId != 0 && BRAC_QueryUserState(g_sOpenedCamUserId, BRAC_USERSTATE_SPEAKVOLUME, (PCHAR)&fSpeakVolume, sizeof(DOUBLE)) == GV_ERR_SUCCESS)
        {
            pwidget->ui->RemoteUserprogressBar->setValue((INT)fSpeakVolume);
        }
        else
        {
            pwidget->ui->RemoteUserprogressBar->setValue(0);
        }
    }
    case REFRESH_AUDIOBITRATE_TIMER:
    {
        int dwAudioBps = 0;
        if (pwidget->m_SelfId != -1 && BRAC_QueryUserState(pwidget->m_SelfId, BRAC_USERSTATE_AUDIOBITRATE, (PCHAR)&dwAudioBps, sizeof(int)) == GV_ERR_SUCCESS)
        {
            dwAudioBps /= 1000;
            pwidget->ui->localAudioBpslabel->setNum(dwAudioBps);
        }
        else
        {
            pwidget->ui->localAudioBpslabel->setNum(0);
        }

        if (g_sOpenedCamUserId != -1 && BRAC_QueryUserState(g_sOpenedCamUserId, BRAC_USERSTATE_AUDIOBITRATE, (PCHAR)&dwAudioBps, sizeof(int)) == GV_ERR_SUCCESS)
        {
            dwAudioBps /= 1000;
            pwidget->ui->RemoteAudioBpslabel->setNum(dwAudioBps);
        }
        else
        {
            pwidget->ui->RemoteAudioBpslabel->setNum(0);
        }
    }
    case REFRESH_VIDEOBITRATE_TIMER:
    {
        int dwVideoBps = 0;
        if (pwidget->m_SelfId != -1 && BRAC_QueryUserState(pwidget->m_SelfId, BRAC_USERSTATE_VIDEOBITRATE, (PCHAR)&dwVideoBps, sizeof(int)) == GV_ERR_SUCCESS)
        {
            dwVideoBps /= 1000;
            pwidget->ui->localVideoBpslabel->setNum(dwVideoBps);
        }
        else
        {
            pwidget->ui->localVideoBpslabel->setNum(0);
        }

        if (g_sOpenedCamUserId != -1 && BRAC_QueryUserState(g_sOpenedCamUserId, BRAC_USERSTATE_VIDEOBITRATE, (PCHAR)&dwVideoBps, sizeof(int)) == GV_ERR_SUCCESS)
        {
            dwVideoBps /= 1000;
            pwidget->ui->RemoteVideoBpslabel->setNum(dwVideoBps);
        }
        else
        {
            pwidget->ui->RemoteVideoBpslabel->setNum(0);
        }
    }
        break;
    default:
        break;
    }

}

// video data callback
void Widget::VideoData_CallBackEx(DWORD dwUserid, LPVOID lpBuf, DWORD dwLen, BITMAPINFOHEADER bmiHeader, DWORD dwTimeStamp, LPVOID lpUserValue)
{
    Widget *pDemoDlg = (Widget*)lpUserValue;

    if(pDemoDlg)
    {
        if(pDemoDlg->m_SelfId == (int)dwUserid)
        {
            if(!pDemoDlg->localeuserpalyer.IsInit())
            {
                pDemoDlg->localeuserpalyer.OpenRenderer((HWND)pDemoDlg->ui->LocalUserlabel->winId(),bmiHeader.biWidth,bmiHeader.biHeight);
            }
            pDemoDlg->localeuserpalyer.AddVideoBuf((CHAR*)lpBuf,dwLen,bmiHeader.biWidth,bmiHeader.biHeight);
        }
        else
        {

            if(!pDemoDlg->RemoteUserplayer.IsInit())
            {

                pDemoDlg->RemoteUserplayer.OpenRenderer((HWND)pDemoDlg->ui->RemoteUserlabel->winId(),bmiHeader.biWidth,bmiHeader.biHeight);
            }
            pDemoDlg->RemoteUserplayer.AddVideoBuf((CHAR*)lpBuf,dwLen,bmiHeader.biWidth,bmiHeader.biHeight);

        }
    }
    return;
}

void Widget::AudioData_CallBackEx(DWORD dwUserid, void *lpBuf, DWORD dwLen, WAVEFORMATEX waveFormatEx, DWORD dwTimeStamp, void *lpUserValue)
{
    Widget *pDemoDlg = (Widget*)lpUserValue;
    if(pDemoDlg)
    {
        if(pDemoDlg->m_SelfId != (int)dwUserid)
        {

        }

    }
}


void CALLBACK Widget::TextMessage_CallBack(DWORD dwFromUserid, DWORD dwToUserid, BOOL bSecret, LPCTSTR lpMsgBuf, DWORD dwLen, LPVOID lpUserValue)
{
    Widget*	pDemoDlg = (Widget*)lpUserValue;
    QString message;
    if(pDemoDlg)
    {
        QDateTime time    = QDateTime::currentDateTime();
        QString   strTime = time.toString("yyyy-MM-dd hh:mm:ss ");
        CHAR      username[120];

        BRAC_GetUserName(dwFromUserid, (TCHAR*)username, sizeof(username));
        emit pDemoDlg->changeSysLogs(username + strTime);
        message.sprintf("%s", lpMsgBuf);
        emit pDemoDlg->changeSysLogs(message);
    }
}

void CALLBACK Widget::NotifyMessage_CallBack(DWORD dwNotifyMsg, DWORD wParam, DWORD lParam, LPVOID lpUserValue)
{
    Widget*	pAnyChatSDKProc = (Widget*)lpUserValue;
    if(!pAnyChatSDKProc)
        return;

    switch(dwNotifyMsg)
    {
    case WM_GV_CONNECT:		    pAnyChatSDKProc->OnGVClientConnect(wParam,lParam);		        break;
    case WM_GV_LOGINSYSTEM:		pAnyChatSDKProc->OnGVClientLogin(wParam,lParam);                break;
    case WM_GV_ENTERROOM:       pAnyChatSDKProc->OnGVClientEnterRoom(wParam,lParam);            break;
    case WM_GV_MICSTATECHANGE:	pAnyChatSDKProc->OnGVClientMicStateChange(wParam,lParam);       break;
    case WM_GV_USERATROOM:		pAnyChatSDKProc->OnGVClientUserAtRoom(wParam,lParam);           break;
    case WM_GV_LINKCLOSE:       pAnyChatSDKProc->OnGVClientLinkClose(wParam, lParam);           break;
    case WM_GV_ONLINEUSER:		pAnyChatSDKProc->OnGVClientOnlineUser(wParam,lParam);           break;

    case WM_GV_CAMERASTATE:		pAnyChatSDKProc->OnAnyChatCameraStateChgMessage(wParam,lParam);	break;
    case WM_GV_ACTIVESTATE:		pAnyChatSDKProc->OnAnyChatActiveStateChgMessage(wParam,lParam);	break;
    case WM_GV_P2PCONNECTSTATE:	pAnyChatSDKProc->OnAnyChatP2PConnectStateMessage(wParam,lParam);break;
    case WM_GV_SDKWARNING:		pAnyChatSDKProc->OnAnyChatSDKWarningMessage(wParam,lParam);     break;

    default:
        break;
    }
    pAnyChatSDKProc->OnAnyChatNotifyMessageCallBack(dwNotifyMsg,wParam,lParam);
};

void Widget::DrawUserVideo(DWORD dwUserid, LPVOID lpBuf, DWORD dwLen, BITMAPINFOHEADER bmiHeader,Widget *pWidget)
{
    if(dwLen <= 0 || lpBuf == NULL)
        return;

    int width  = bmiHeader.biWidth;
    int height = bmiHeader.biHeight;

    if (pWidget == NULL)
        return;

    if(m_SelfId == (int)dwUserid)
    {
        char* p = m_lpLocalVideoFrame;
        if(  !p ||m_iLocalVideoSize < (int)dwLen)
        {
            p = (char*)realloc(p, dwLen);
            if(!p)
                return;
            m_iLocalVideoSize = dwLen;
        }
        memcpy(p, lpBuf, dwLen);
        QImage img = QImage((uchar *)p,width,height,QImage::Format_RGB32);// can load the image
#ifdef  WIN32
        QImage img2 = img.mirrored();
        pWidget->ui->LocalUserlabel->setPixmap(QPixmap::fromImage(img2));
#else
        pWidget->ui->LocalUserlabel->setPixmap(QPixmap::fromImage(img));
#endif
        free(p);
        p = NULL;
    }
    else
    {
        char* p = m_lpRemoteVideoFrame;
        if(  !p ||m_iRemoteVideoSize < (int)dwLen)
        {
            p = (char*)realloc(p, dwLen);
            if(!p)
                return;
            m_iRemoteVideoSize = dwLen;
        }
        memcpy(p, lpBuf, dwLen);
        QImage img = QImage((uchar *)p,width,height,QImage::Format_RGB32);// can load the image
#ifdef  WIN32
        QImage img2 = img.mirrored();
        pWidget->ui->RemoteUserlabel->setPixmap(QPixmap::fromImage(img2));
#else
        pWidget->ui->RemoteUserlabel->setPixmap(QPixmap::fromImage(img));
#endif
        free(p);
        p = NULL;
    }
}

void Widget::on_UserlistWidget_doubleClicked(const QModelIndex &index)
{
    int row = ui->UserlistWidget->currentRow();
    if(g_sOpenedCamUserId != 0)
    {
        BRAC_UserCameraControl(g_sOpenedCamUserId,0);
        BRAC_UserSpeakControl(g_sOpenedCamUserId,0);

        g_sOpenedCamUserId = 0;
        ui->RemoteUserlabel->clear();
    }
    BRAC_SetVideoPos(m_iUserID[row], (HWND)this->winId(), m_RemoteUser.left(), m_RemoteUser.top(), m_RemoteUser.right(), m_RemoteUser.bottom());

    BRAC_UserCameraControl(m_iUserID[row],1);
    BRAC_UserSpeakControl (m_iUserID[row],1);

    g_sOpenedCamUserId = m_iUserID[row];
}


void Widget::on_SendMsg_Btn_clicked()
{
    QString message = ui->SendMsglineEdit->text();
    if(g_sOpenedCamUserId==0)
    {
        AppendLogString("#ERROR# No user chat with you");
        AppendLogString("#ERROR# Please request chat first");
        ui->SendMsglineEdit->setText("");
        return ;
    }

    if((BRAC_SendTextMessage(g_sOpenedCamUserId, FALSE, (LPCTSTR)message.toStdString().c_str(), message.toStdString().length()))== 0)
    {
        QDateTime time = QDateTime::currentDateTime();
        QString strTime = time.toString("  yyyy-MM-dd hh:mm:ss ");
        QString info ="#INFO#";
        CHAR username[120];
        BRAC_GetUserName(g_sOpenedCamUserId, (TCHAR*)username, sizeof(username));
        AppendLogString(info + username + strTime);
        AppendLogString(message);
    }

    ui->SendMsglineEdit->setText("");
}

void Widget::on_Appid_checkBox_clicked()
{
    if(ui->Appid_checkBox->isChecked())
        ui->Appid_lineEdit->setEnabled(true);
    else
        ui->Appid_lineEdit->setEnabled(false);
}

void Widget::on_Login_btn_clicked()
{
    if(!m_isLogin)
    {
        HelloChatInit();
        HelloChatLogin();
    }
    else
    {
        m_isLogin = false;
        ui->Login_btn->setText("Login");

        BRAC_UserCameraControl(g_sOpenedCamUserId, 0);
        BRAC_UserSpeakControl(g_sOpenedCamUserId, 0);
        ui->RemoteUserlabel->clear();
        ui->RemoteUserlabel->setText("RemoteUser");

        BRAC_UserCameraControl(m_SelfId, 0);
        BRAC_UserSpeakControl(m_SelfId, 0);
        ui->LocalUserlabel->clear();
        ui->LocalUserlabel->setText("LocalUser");

        BRAC_LeaveRoom(1);

        HelloChatRefreshUserList();
        AppendLogString("#INFO# User Leave Room");
        g_sOpenedCamUserId = 0;

        BRAC_Logout();
        BRAC_Release();
        m_dwTransTaskId = -1;

    }
}

void Widget::on_VADcheckBox_clicked(bool checked)
{
    m_bEnableVAD = checked;
    BRAC_SetSDKOption(BRAC_SO_AUDIO_VADCTRL,(PCHAR)&m_bEnableVAD,sizeof(m_bEnableVAD));
}

void Widget::on_AECcheckBox_clicked(bool checked)
{

    m_bEnableEcho =checked;
    BRAC_SetSDKOption(BRAC_SO_AUDIO_ECHOCTRL,(PCHAR)&m_bEnableEcho,sizeof(m_bEnableEcho));
}

void Widget::on_AGCcheckBox_clicked(bool checked)
{

    m_bEnableAGC =checked;
    BRAC_SetSDKOption(BRAC_SO_AUDIO_AGCCTRL,(PCHAR)&m_bEnableAGC,sizeof(m_bEnableAGC));

}

void Widget::on_NScheckBox_clicked(bool checked)
{
    m_bEnableNS = checked;
    BRAC_SetSDKOption(BRAC_SO_AUDIO_NSCTRL,(PCHAR)&m_bEnableNS,sizeof(m_bEnableNS));
}

void Widget::on_wavhorizontalSlider_valueChanged(int value)
{
    BRAC_AudioSetVolume(BRAC_AD_WAVEOUT,value);
}

void Widget::on_michorizontalSlider_valueChanged(int value)
{
    BRAC_AudioSetVolume(BRAC_AD_WAVEIN,value);
}

void Widget::on_Setdelay_clicked()
{
    QString delay = ui->delay_edit->text();
    int echodelay=delay.toInt();
    BRAC_SetSDKOption(BRAC_SO_AUDIO_ECHODELAY,(PCHAR)&echodelay,sizeof(echodelay));
}

void Widget::on_RecordRemoteUser_clicked()
{
    static BOOL bLastState = FALSE;
    if(g_sOpenedCamUserId != 0)
    {
        DWORD dwFlags = ANYCHAT_RECORD_FLAGS_AUDIO | ANYCHAT_RECORD_FLAGS_VIDEO;
        BRAC_StreamRecordCtrlEx(g_sOpenedCamUserId, !bLastState, dwFlags, 0,"hellow world!");
        bLastState = !bLastState;
    }
    else
    {
        AppendLogString("#ERROR# No user chat with you");
        AppendLogString("#ERROR# Please request chat first");
    }
}

void Widget::on_SnapShot_clicked()
{
    if(g_sOpenedCamUserId != 0)
    {
        BRAC_SnapShot(g_sOpenedCamUserId,0,0);
    }
    else
    {
        AppendLogString("#ERROR# No user chat with you");
        AppendLogString("#ERROR# Please request chat first");
    }
}

void Widget::on_sendFileBtn_clicked()
{
    if(m_dwTransTaskId != -1)
        return;

    QString path = QFileDialog::getOpenFileName(this);  //NULL, tr("打开"), "/", tr("Any files(*)")
    if(! path.isEmpty())
    {
        DWORD dwTaskId = 0 ;
        DWORD wParam = 1 ;
        DWORD lParam = 2;
        DWORD dwFlags = 0;
        AppendLogString(path);
        DWORD ret =BRAC_TransFile(g_sOpenedCamUserId, (LPCTSTR)path.toStdString().c_str(), wParam, lParam, dwFlags, dwTaskId);
        if(ret == GV_ERR_SUCCESS)      //0表示任务建立成功
        {
            m_dwTransTaskId = dwTaskId;
            QString str;
            str.sprintf("%d", m_dwTransTaskId);
            AppendLogString(str);
            m_iTranstimerid=startTimer(100);
        }
        else
        {
            QString strError;
            strError.sprintf("创建文件传输任务失败，出错代码：%d", ret);
            AppendLogString(strError);
            ui->fileStatuslabel->setText("文件传输失败！");
        }
    }
}

void Widget::on_sendBufBtn_clicked()
{
    if(m_dwTransTaskId != -1)	// 演示程序为了简洁，同时只允许传一个任务，实际上SDK是可以多任务并发的
        return;

    PCHAR lpBuf = (PCHAR)malloc(10*1024);		// 为了演示，创建一个10KByte大小的缓冲区
    if(!lpBuf)
        return;
    DWORD dwLen = 10*1024;
    lpBuf[1000] = 'Y';			// 演示的需要，为了验证收到的数据是否正确，在缓冲区中间某个位置设置一个标志，对方接收后，可判断该标志是否为设定值

    DWORD dwTaskId = 0;
    DWORD wParam = 3;			// 上层应用程序可自定义wParam、lParam的值，这两个参数的值将被回调给对方
    DWORD lParam = 4;
    DWORD dwFlags = 0;			// 该标志设置为0，则SDK将自动根据网络状态选择合适的传输途径（TCP、UDP or P2P）
    DWORD ret =BRAC_TransBufferEx(g_sOpenedCamUserId,(PBYTE)lpBuf,dwLen,wParam,lParam,dwFlags,dwTaskId);
    if(ret == GV_ERR_SUCCESS)
    {
        m_dwTransTaskId = dwTaskId;
        m_iTranstimerid=startTimer(100);
    }
    else
    {
        QString strError;
        strError.sprintf("创建缓冲区传输任务失败，出错代码:%d",ret);
        AppendLogString(strError);
        ui->fileStatuslabel->setText("");
    }
    // 缓冲区调用完成后， 可以立即释放掉
    free(lpBuf);
}
