#ifndef AIHELPER_H
#define AIHELPER_H
#include <string>
#include "BRAnyChatCoreSDK.h"
#include "GVMessageDefine.h"
#include <time.h>
#include "airobotdefine.h"
#if defined(WIN32)
#else
#include <unistd.h>
#	include <uuid/uuid.h>			// need link -luuid
#endif
#ifndef ANYCHAT_CORESDKEVENT_AIABILITY
#define ANYCHAT_CORESDKEVENT_AIABILITY 102 //AI�����¼�
#endif
#ifndef ANYCHAT_SDKCTRL_AIABILITY
#define ANYCHAT_SDKCTRL_AIABILITY 102
#endif
#ifndef AC_ERROR_AI_ABILITY_ROBOTOFFLINE
#define AC_ERROR_AI_ABILITY_ROBOTOFFLINE		200014			///< ����������
#endif

class AIhelper{
public:

    BOOL        m_bAiRobotIsCreate;
    BOOL        m_bASRisStart;//Asr�Ƿ�ʼ
    BOOL        m_bAirobotCreateErr;

    AIhelper();
    ~AIhelper()=default;

    int AICreate();
    int AIRelease();
    int AITTS(int TTSmode,char* content,int istest);//1base64 2 ����
    int AIASRStart(int istest);
    int AIASREnd();
    void uuid_conver(char* source,char* desc);
private:

    char*		m_szStrUserID;
    char    	m_GRobootGuid[128];
    char    	m_GTTStaskid[128];
    char    	m_GAsrTaskid[128];
};
#endif //!AIHELPER_H
