#include "database.h"

DataBase::DataBase()
{
    createConnection();
}

DataBase::~DataBase()
{
    if(db.isOpen())
        db.close();
}
//建立一个数据库连接
bool DataBase::createConnection()
{
    //以后就可以用"sqlite1"与数据库进行连接了
    db= QSqlDatabase::addDatabase("QSQLITE", "sqlite1");
    db.setDatabaseName(".//RobotDb.db");
    if( !db.open())
    {
        qDebug() << "无法建立数据库连接";
        return false;
    }
    return true;
}
bool DataBase::queryquestions( char *szquestions,char *szanswers,  unsigned int buffsize)
{
    bool res=false;
    do{
        if(!db.isOpen())
            break;
        QSqlQuery query(db);
        int offset=0;
        bool success=false;
        do
        {
            query.prepare("select questions,answers from RobotReplytable LIMIT 100 OFFSET ?");
            query.addBindValue(offset);
            offset+=100;
            success=query.exec();
            if(!success)
            {
                break;
            }
            if (query.last())
            {
                if(query.at() + 1<=0)
                {
                    break;
                }
            }
            else
                break;
            query.first();//重新定位指针到结果集首位
            query.previous();//如果执行query.next来获取结果集中数据，要将指针移动到首位的上一位。
            while(query.next())
            {
                if(strstr(szquestions, query.value(0).toString().toStdString().c_str()) != NULL)
                {
                    snprintf(szanswers, (size_t)buffsize, "%s", query.value(1).toString().toStdString().c_str());
                    szanswers[buffsize-1] = '\0';
                    res=true;
                    break;
                }
            }
        }while(success);

    }while(false);
    return res;
}




