#ifndef CONTROLUI_H
#define CONTROLUI_H
#include "ai.h"
#include "Define.h"
#include "mainwindow.h"
#include <QDebug>

using namespace std;
class controlUI : public QObject
{
     Q_OBJECT
public:
    controlUI();
    //显示第一个界面
    int ShowVideoWin();
    //从第一个界面切换到第二个界面
    int ShowAiWin();


    //第一个界面，获得绘画远端PC视频画面的句柄
    int GetHandle(QLabel *label, int HandleType);





    //申请一个对象

    //1.AI界面，显示AI机器人的内容 return -1.则是该对象已经被销毁。
    int ShowContent(int handle, int type, int time, bool isContinue,string& textContent);


private:
    AI * m_ai;
    MainWindow * m_mainwindow;

};

#endif // CONTROLUI_H
