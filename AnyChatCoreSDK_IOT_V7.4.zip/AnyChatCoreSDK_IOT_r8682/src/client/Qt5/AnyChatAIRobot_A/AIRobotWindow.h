#ifndef AIROBOTWINDOW_H
#define AIROBOTWINDOW_H

#include <QMainWindow>
#include "robotdefine.h"
#include <QTimer>
#include <qdebug.h>
#include <atomic>
#define debug_interrupt
using namespace std;
namespace Ui {
class AIRobotWindow;
}

class AIRobotWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AIRobotWindow(QWidget *parent = nullptr);
    ~AIRobotWindow();

    int ShowMessage(AIMESSAGETYPE type, string szMessage,bool isEnd, int time, int asrtimer);

    bool IsLowPerformance(){
        return m_IsLowPerformance;
    }
signals:
    /**
     * 信号必须要signals关键字来声明
     * 信号没有返回值, 但可以有参数
     * 信号就是函数的声明, 无需定义
     * 使用: emit mySignal();
     * 信号可以被重载
     */
    int winToVideo();




private:
    Ui::AIRobotWindow *ui;
    vector <AIObject *>AIObjectVector;
    QTimer * m_timerPlay_Robbt;
    QTimer * m_timerPlay_User;
    QTimer * m_timerUserRecord;
    QTimer * m_timer_gif;
    QLabel * m_giflabelASR;
    QLabel * m_labelUserRecordtime;
    bool PlayComplete;
    bool RobotGifRun;
    AIMESSAGETYPE m_type;
    int m_state;
    int m_timeUserRecordtime;
    int m_timer_gif_num;

    int m_Playgifname_robot;
    int m_Playgifname_User;
    int time_num_robot;
    int time_num_user;
    int m_time;
    int m_iUserMessgeHandle;
    int m_iRobotMessageHandle;
	int m_CurrentPosition;

    bool IsInitTableWidget;

    bool m_IsLowPerformance;
    atomic_int m_ShowContentRunningNum;//原子数据，用来记录当前是否有进行ShowContent，避免和clear句柄的操作冲突

    int InitTableWidget();
    int Interruptplay(AIMESSAGETYPE type);
    int clearAIObject();
    int SwitchGifState(int state);


    int ApplyHandle(AIMESSAGETYPE type);
    /*******************************************************
     *int handle:  ApplyHandle返回的句柄
     *string textContent：需要显示的内容
     *当句柄类型为AI_Robot，time可不传或传0，则不会显示时间，ASRTimer参数无效，可不传
     *当句柄类型为AI_User，ASRTimer为ASRRuning、ASRstart、ASRStop，则time无效，可传0，
     *ASRTimer为ASRComplete，则time生效，显示时间。
     *默认为ASRRuning，此时可不传该参。
     *第一次调用显示的时候，传ASRstart，开始自动计时并显示时间，已结束此段录音，则传ASRStop，以停止计时。
     *使用示例：
     *string text = {"你好，我是小A机器人"};
     *int handlefn = m_ai->ApplyHandle(AI_Robot);
     *m_ai->ShowContent(handlefn,text,10);

     *handlefn = m_ai->ApplyHandle(AI_User);
     *m_ai->ShowContent(handlefn,text,0,ASRstart);
     *******************************************************/


    int ShowContent(int handle,string& textContent,int time = 0,int ASRTimer  = ASRRuning);
    bool initLowPerformance();
private slots:
    int Inplay_Robot();
    int Inplay_User();
    int RobotGif();
    int UpdateUserRecordtime();
};

#endif // AIROBOTWINDOW_H
