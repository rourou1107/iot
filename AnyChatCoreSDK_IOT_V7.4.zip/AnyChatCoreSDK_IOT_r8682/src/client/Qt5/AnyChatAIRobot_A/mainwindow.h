#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include"sdlplayer.h"
#include "BRAnyChatCoreSDK.h"
#include "AIhelper.h"
#include "database.h"
#include "AIRobotWindow.h"
#include <QMetaType>
#define MAX_USER_NUM 10
#define MAX_VIDEOFRAME_NUM 2

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    int     m_SelfId;               //自己的ID
    int     m_iUserID[MAX_USER_NUM];//其他用户ID号
    int     m_ivadcount;//静音500ms　结束倾听
    int     m_iAskcount;
    double  m_fSpeakVolume; //音量
    long    m_laudioplaytime;
    long    m_lAsktime;
    bool    m_bTTSstart;
    bool    m_bAsrResultstart;

    bool    m_bTTSIspalyback;
    bool    m_bRobotIsExit;
    bool    m_isLogin;              // login server
    SdlPlayer m_Localeuserpalyer;
    SdlPlayer m_RemoteUserplayer;
    AIhelper  m_Aihelper;
public:

    void AnyChatSDKInit();      //初始化
    void AnyChatSDKLogin();     //登陆服务器
    void switchingwindow(CHAR*szResult);
    DWORD AnalyzeResult(CHAR* szResultstr,DWORD dwAievent ,DWORD dwAitype);
    int ChangeWinTOAI();
    int ChangeWinTOVideo();
    //以下为异步消息回调，初始化的时候设置
    long OnGVClientConnect(WPARAM wParam, LPARAM lParam);
    long OnGVClientLogin(WPARAM wParam, LPARAM lParam);
    long OnGVClientEnterRoom(WPARAM wParam, LPARAM lParam);
    long OnGVClientOnlineUser(WPARAM wParam, LPARAM lParam);
    long OnGVClientMicStateChange(WPARAM wParam, LPARAM lParam);
    long OnGVClientUserAtRoom(WPARAM wParam, LPARAM lParam);
    long OnGVClientLinkClose(WPARAM wParam, LPARAM lParam);
    long RobotMessageEvent(DWORD dwMsg,LPCTSTR lpQuestionsStr,LPCTSTR lpAnswerStr,WPARAM wParm);

    virtual void OnAnyChatCameraStateChgMessage(DWORD dwUserId, DWORD dwState){}   // 用户摄像头状态改变消息
    virtual void OnAnyChatActiveStateChgMessage(DWORD dwUserId, DWORD dwState){}   // 用户活动状态发生变化消息
    virtual void OnAnyChatP2PConnectStateMessage(DWORD dwUserId, DWORD dwState){}    // P2P连接状态变化消息
    virtual void OnAnyChatPrivateRequestMessage(DWORD dwUserId, DWORD dwRequestId){}// 用户私聊请求消息
    virtual void OnAnyChatPrivateEchoMessage(DWORD dwUserId, DWORD dwErrorCode){}  // 用户私聊请求回复消息
    virtual void OnAnyChatPrivateExitMessage(DWORD dwUserId, DWORD dwErrorCode){}  // 用户退出私聊消息
    virtual void OnAnyChatSDKWarningMessage(DWORD dwErrorCode, DWORD dwReserved){} // SDK警告消息

    virtual void OnAnyChatNotifyMessageCallBack(DWORD dwNotifyMsg, DWORD wParam, DWORD lParam){}// 异步消息通知回调函数
    void static CALLBACK VideoData_CallBackEx(DWORD dwUserid, LPVOID lpBuf, DWORD dwLen, BITMAPINFOHEADER bmiHeader, DWORD dwTimeStamp, LPVOID lpUserValue);
    void static CALLBACK AudioData_CallBackEx(DWORD dwUserid, LPVOID lpBuf, DWORD dwLen, WAVEFORMATEX waveFormatEx, DWORD dwTimeStamp, LPVOID lpUserValue);
    void static CALLBACK NotifyMessage_CallBack(DWORD dwNotifyMsg, DWORD wParam, DWORD lParam, LPVOID lpUserValue);
    void static CALLBACK OnAnyChatCoreSDKEvent(DWORD dwEventType, LPCTSTR lpEventJsonStr, LPVOID lpUserValue);

signals:
    void ShowMessage(AIMESSAGETYPE type, std::string szMessage,bool isEnd, int time, int asrtimer);
    void setyuv(uchar *ptr,uint width,uint height);
    void setyuv2(uchar*,uint,uint);
private slots:
    void ChangePicture();
    void AIwindowShowMessage(AIMESSAGETYPE type, std::string szMessage,bool isEnd, int time, int asrtimer);
protected:
    virtual void resizeEvent(QResizeEvent *event) override;
private:
    Ui::MainWindow *ui;
    DataBase RobotDatabase;
    QString szRobotmessage;
    QTimer * m_timer;
    AIRobotWindow * m_AIRobotWindow;
    int InitUI();
    int InitConnect();
    int m_gifname = 10000;
    bool m_bisStart=false;
    //该函数用于非阻塞延迟，切换窗口后使用，避免切换窗口后立刻刷新控件，这样会导致控件刷新和界面显示排在GUI线程的同一个任务中，导致界面显示慢。
    void msecSleep(int msec);


};

#endif // MAINWINDOW_H
