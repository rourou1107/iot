#include "mainwindow.h"
#include<time.h>
#include "ui_mainwindow.h"
#include "cjsonutil.h"
#include "robotdefine.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    qRegisterMetaType<AIMESSAGETYPE>("AIMESSAGETYPE");
    qRegisterMetaType<std::string>("std::string");
    ui->setupUi(this);
    m_AIRobotWindow = new AIRobotWindow();
    m_timer = new QTimer(this);
    InitUI();
    InitConnect();
    memset(m_iUserID,-1,sizeof(m_iUserID));
    m_fSpeakVolume = 0.0;
    m_isLogin     = false;
    m_bTTSstart   =false;
    m_bTTSIspalyback=false;
    m_bAsrResultstart=false;
    m_iAskcount=0;
    m_ivadcount=0;
    m_bRobotIsExit=true;
    m_laudioplaytime=0;
    m_lAsktime=0;
    connect(this,SIGNAL(ShowMessage(AIMESSAGETYPE,std::string,bool,int,int)),this,SLOT(AIwindowShowMessage(AIMESSAGETYPE,std::string,bool,int,int)));
    SdlPlayer::SdlInit();
    AnyChatSDKInit();
    AnyChatSDKLogin();
    if(!m_AIRobotWindow->IsLowPerformance())
        m_timer->start(50);
}

MainWindow::~MainWindow()
{
    BRAC_Release();
    SdlPlayer::SdlRelease();
    delete ui;
    if(m_timer)
    {
        delete m_timer;
        m_timer = nullptr;
    }
    if(m_AIRobotWindow)
    {
        delete m_AIRobotWindow;
        m_AIRobotWindow = nullptr;
    }
}
int MainWindow::InitUI()
{
    //将窗口放大
    //QWidget::showMaximized();
    ChangePicture();
    return 0;
}

int MainWindow::InitConnect()
{
    int (AIRobotWindow::*funSignal)() = &AIRobotWindow::winToVideo;
    int (MainWindow::*funSlot)() = &MainWindow::ChangeWinTOVideo;
    connect(m_AIRobotWindow, funSignal, this, funSlot);
    connect(m_timer,SIGNAL(timeout()),this,SLOT(ChangePicture()));
    return 0;
}

void MainWindow::ChangePicture()
{

    QString CSS;
    CSS.sprintf("border-image:url(:/image/gif-1/%d.png)",m_gifname);
    ui->Giflabel->setStyleSheet(CSS);
    m_gifname++;

    if(m_gifname == 10099)
    {
        m_gifname = 10000;
    }
}

void MainWindow::AIwindowShowMessage(AIMESSAGETYPE type, std::string szMessage,bool isEnd, int time, int asrtimer)
{
    m_AIRobotWindow->ShowMessage(type,szMessage,isEnd,time,asrtimer);

}


//切换到第二个界面
int MainWindow::ChangeWinTOAI()
{
    m_timer->stop();
    this->hide();
    //m_AIRobotWindow->showMaximized();
    m_AIRobotWindow->show();
    //非阻塞延时，等待100毫秒，避免马上刷新控件，导致界面显示需要等待一段时间。
    msecSleep(100);
    return 0;
}

//切换到第一个界面
int MainWindow::ChangeWinTOVideo()
{
    ChangePicture();
    m_AIRobotWindow->hide();
    this->show();
    //非阻塞延时，等待100毫秒，避免马上刷新控件，导致界面显示需要等待一段时间。
    msecSleep(100);
    m_timer->start(50);
    return 0;

}
void MainWindow::msecSleep(int msec)
{
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() <dieTime )
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

void MainWindow::AnyChatSDKInit()
{
    //获取SDK的版本信息
    DWORD dwMainVer,dwSubVer;
    TCHAR szCompileTime[100] = {0};
    BRAC_GetSDKVersion(dwMainVer, dwSubVer, (TCHAR*)szCompileTime, sizeof(szCompileTime));
    //打开（关闭）SDK的日志记录功能
    BRAC_ActiveCallLog(true);


    //设置SDK核心组件所在目录（注：demo程序只是设置为当前目录，项目中需要设置为实际路径）
    QString szCoreSDKPath;
    szCoreSDKPath = QCoreApplication::applicationDirPath();
    (strrchr((char*)szCoreSDKPath.toStdString().c_str(),'/'))[1] = 0;
    BRAC_SetSDKOption(BRAC_SO_CORESDK_PATH,(char*)szCoreSDKPath.toStdString().c_str(),strlen((char*)szCoreSDKPath.toStdString().c_str()));
    // 根据BRAC_InitSDK的第二个参数：dwFuncMode，来告诉SDK该如何处理相关的任务（详情请参考开发文档）
    DWORD dwFuncMode = BRAC_FUNC_VIDEO_CBDATA|BRAC_FUNC_AUDIO_AUTOPLAY | BRAC_FUNC_CHKDEPENDMODULE |
                    BRAC_FUNC_AUDIO_VOLUMECALC | BRAC_FUNC_NET_SUPPORTUPNP | BRAC_FUNC_FIREWALL_OPEN |
                    BRAC_FUNC_AUDIO_AUTOVOLUME | BRAC_FUNC_AUDIO_VOLUMECALC | BRAC_FUNC_CONFIG_LOCALINI;
    BRAC_InitSDK((HWND)this->winId(), dwFuncMode);
    BRAC_SetVideoDataExCallBack(BRAC_PIX_FMT_YUV420P,VideoData_CallBackEx,this);
    BRAC_SetAudioDataExCallBack(AudioData_CallBackEx,this);
    BRAC_SetNotifyMessageCallBack(NotifyMessage_CallBack,this);
    BRAC_SetCallBack(BRAC_CBTYPE_CORESDKEVENT,(void*)OnAnyChatCoreSDKEvent,this);

    BOOL bAudioEnable=TRUE;
    BRAC_SetSDKOption(BRAC_SO_AUDIO_AGCCTRL,(PCHAR)&bAudioEnable,sizeof(bAudioEnable));
    BRAC_SetSDKOption(BRAC_SO_AUDIO_VADCTRL,(PCHAR)&bAudioEnable,sizeof(bAudioEnable));
    BRAC_SetSDKOption(BRAC_SO_AUDIO_NSCTRL,(PCHAR)&bAudioEnable,sizeof(bAudioEnable));
    BRAC_SetSDKOption(BRAC_SO_AUDIO_ECHOCTRL,(PCHAR)&bAudioEnable,sizeof(bAudioEnable));


    // 设置服务器认证密码
    QString pwd = "BaiRuiTech";
    BRAC_SetServerAuthPass((LPCTSTR)pwd.toStdString().c_str());
}

void MainWindow::AnyChatSDKLogin()
{
    BRAC_Connect("120.76.248.33", 8906);
    BRAC_Login("RobootA", "", 0);
    BRAC_EnterRoom(100861,"", 0);
}
//机器人回复仅供验证使用，使用读取本地数据库进行回复
//分析json中的result　并进行处理
DWORD MainWindow::AnalyzeResult(CHAR *szResultstr, DWORD dwAievent, DWORD dwAitype)
{
    if(dwAievent!=4 &&(dwAitype!=1 ||dwAitype!=2))
        return -1;
    DWORD dwstatus=0;
    CJsonUtil::GetIntValue(szResultstr,"status",dwstatus);
    if(dwAievent == 4 && dwAitype == 1&&CJsonUtil::IsJsonKeyExist(szResultstr,"result"))
    {

        DWORD dwsentenceflag=0;
        CJsonUtil::GetIntValue(szResultstr,"sentenceflag",dwsentenceflag);
        char szAsrRes[2048]={0};
        CJsonUtil::GetStrValue(szResultstr,"result",szAsrRes,sizeof(szAsrRes));
        char answers[2048]={0};
        if(!m_bTTSstart)
        {
            if(dwsentenceflag==1&&!m_bRobotIsExit)
            {
                timeval start;
                gettimeofday(&start, NULL);
                m_lAsktime= 1000*(start.tv_sec) + (start.tv_usec)/1000;
            }
            else if(dwsentenceflag==3)
            {
                if(m_lAsktime!=0)
                {
                    timeval end;
                    gettimeofday(&end, NULL);
                    m_lAsktime= 1000*(end.tv_sec) + (end.tv_usec)/1000-m_lAsktime;

                }
                bool isAsk=false;
                if(strstr(szAsrRes, ROUSEROBOTSTR) != NULL)
                    isAsk=true;
                if(isAsk||m_iAskcount>0)
                    m_iAskcount+=1;
                if(isAsk&&m_bRobotIsExit)  //唤醒机器人
                {
                    const char *str="你好,智能机器人安妮为您服务";
                    RobotMessageEvent(ROUSEROBOT,szAsrRes,str,1);
                    m_bTTSstart=true;
                    m_Aihelper.AITTS(2,const_cast<char*>(str),0);
                    szRobotmessage=str;

                    m_iAskcount=0;
                    qDebug()<<"debug 唤醒机器人\r\n";
                }
                else if(strstr(szAsrRes,EXITROBOTSTR)!=NULL)//退出机器人
                {
                    RobotMessageEvent(EXITROBOT,NULL,NULL,1);
                    qDebug()<<"debug 退出机器人\r\n";
                }
                else if(strlen(szAsrRes)>0 &&m_iAskcount>0&&RobotDatabase.queryquestions(szAsrRes,answers,sizeof(answers))&&!m_bRobotIsExit)
                {
                    std::string szmessage=szAsrRes;
                    if(m_iAskcount==1)
                    {
                        int pos = 0;
                        while ((pos = szmessage.find(ROUSEROBOTSTR)) != -1)
                        {
                            szmessage.erase(pos, strlen(ROUSEROBOTSTR));
                        }
                    }
                    RobotMessageEvent(ASRSENTTENCETIME,szmessage.c_str(),NULL,1);
                    m_lAsktime=0;

                    qDebug("szAsrRes %s question %s \r\n",szmessage.c_str(),answers);
                    szRobotmessage=answers;
                    m_bTTSstart=true;
                    m_Aihelper.AITTS(2,answers,0);

                    m_iAskcount=0;
                }
                else if(!m_bRobotIsExit&&m_iAskcount>=2)
                {
                    char cmp[2048]={0};
                    if(strcmp(szAsrRes,cmp)!=0)
                    {
                        RobotMessageEvent(ASRSENTTENCETIME,szAsrRes,NULL,1);
                        RobotMessageEvent(ROBOTTTSPLAYBACK,NULL,"暂时找不到答案呢  可以换个问题吗，比如你可以问我的名字",1);
                        szRobotmessage="暂时找不到答案呢  可以换个问题吗，比如你可以问我的名字";
                        qDebug()<<"find question null \r\n";
                    }
                }
                if(m_iAskcount==1)
                {
                    const char* szmessage="安妮在的请讲!";
                    szRobotmessage=szmessage;
                     m_bTTSstart=true;
                    m_Aihelper.AITTS(2,const_cast<char*>(szmessage),0);

                }
                char cmp[2048]={0};
                if(m_iAskcount>=2&&strcmp(szAsrRes,cmp)==0)
                {
                    m_iAskcount=1;
                }
                else if(m_iAskcount>=2)
                {
                    m_iAskcount=0;
                }
                m_lAsktime=0;
            }
        }

        std::string logstr;
        logstr+="AIRobot:CoreSDKEvent:asr::";
        logstr+=szAsrRes;
    qDebug()<<logstr.c_str();
    }
    else if(dwAievent == 4 && dwAitype == 2)
    {
        if(dwstatus==1)
        {
            timeval start;
            gettimeofday(&start, NULL);
            m_laudioplaytime= 1000*(start.tv_sec) + (start.tv_usec)/1000;
            RobotMessageEvent(ROBOTTTSPLAYBACK,NULL,szRobotmessage.toStdString().c_str(),3);
        }
        if(dwstatus==3)
        {
            timeval end;
            gettimeofday(&end, NULL);
            m_laudioplaytime= 1000*(end.tv_sec) + (end.tv_usec)/1000-m_laudioplaytime;
            RobotMessageEvent(ROBOTTTSPLAYBACK,NULL,szRobotmessage.toStdString().c_str(),0);
            m_bTTSstart=false;
            m_laudioplaytime=0;
        }
    }
    return 0;
}

long MainWindow::OnGVClientConnect(WPARAM wParam, LPARAM lParam)
{
    bool bSuccess = (bool)wParam;
    QString str(bSuccess ? "#INFO# Connect to server OK" : "#INFO# Connect to Server error");
    return 0;
}

long MainWindow::OnGVClientLogin(WPARAM wParam, LPARAM lParam)
{
    QString logstr;
    DWORD dwUserID = wParam;
    if(lParam == 0)
    {
        CHAR username[120];
        BRAC_GetUserName(dwUserID,(TCHAR*)username,sizeof(username));
        logstr.sprintf("#INFO# Login Server OK UserId %d(%s)", dwUserID, username);

        m_SelfId= dwUserID;
        m_isLogin = true;
    }
    else
        logstr.sprintf("#INFO# Login  Server Error  %d ", lParam);
    return 0;
}

long MainWindow::OnGVClientEnterRoom(WPARAM wParam, LPARAM lParam)
{
    QString logstr;
    int roomid = (int)wParam;

    if(lParam == 0)
    {
        logstr.sprintf("#INFO# Success enter room %d,user %d",roomid, m_SelfId);

        //Open Local Camera
        BRAC_UserCameraControl(-1, TRUE);
        BRAC_UserSpeakControl(-1, TRUE);
        m_Aihelper.AICreate();

    }
    else
    {
        logstr.sprintf("#INFO# Can not enter room Error code  %d ",lParam);
    }

    return 0;
}

long MainWindow::OnGVClientOnlineUser(WPARAM wParam, LPARAM lParam)
{
    DWORD dwUserNum = 0;
    BRAC_GetOnlineUser(NULL, dwUserNum);		///< 首先获取房间内在线人数
    if (!dwUserNum)
        return 0;

    LPDWORD lpdwUserList = (LPDWORD)malloc(sizeof(DWORD)*dwUserNum);
    BRAC_GetOnlineUser(lpdwUserList, dwUserNum);	///< 真正获取在线用户列表

    for (INT i = 0; i < (INT)dwUserNum; i++)
    {
        DWORD userid = lpdwUserList[i];
        // 给用户找一个空的位置显示面板（第0号位置留给自己）
        INT site = -1;
        for (INT i = 1; i < MAX_VIDEOFRAME_NUM; i++)
        {
            if (m_iUserID[i] == -1)
            {
                site = i;
                break;
            }
        }
        if (site != -1)
        {
            // BRAC_SetVideoPos(userid, (HWND)this->winId(), m_UserRect[site].left, m_UserRect[site].top, m_UserRect[site].right, m_UserRect[site].bottom);
            BRAC_UserCameraControl(userid, TRUE);
            if(m_bRobotIsExit)
                BRAC_UserSpeakControl(userid, TRUE);

            DWORD dwState = 0;
            BRAC_GetCameraState(userid, dwState);
            m_iUserID[site] = userid;
        }
        else
            break;
    }

    free(lpdwUserList);
    return 0;
}

long MainWindow::OnGVClientMicStateChange(WPARAM wParam, LPARAM lParam)
{
    QString logstr;
    logstr.sprintf("#INFO# User id %d ", wParam);
    logstr.append( lParam ? "open":"close");
    logstr.append(" Local Mic Device");

    return 0;
}

long MainWindow::OnGVClientUserAtRoom(WPARAM wParam, LPARAM lParam)
{
    INT		userid = (INT)wParam;
    BOOL	bEnter = (BOOL)lParam;

    CHAR username[30] = { 0 };
    BRAC_GetUserName(userid, username, sizeof(username));


    if (bEnter)
    {
        // 给用户找一个空的位置显示面板（第0号位置留给自己）
        INT site = -1;
        for (INT i = 1; i < MAX_VIDEOFRAME_NUM; i++)
        {
            if (-1 == m_iUserID[i])
            {
                site = i;
                break;
            }
        }
        if (site != -1)
        {
            BRAC_UserCameraControl(userid, TRUE);
            if(m_bRobotIsExit)
                BRAC_UserSpeakControl(userid, TRUE);
            m_iUserID[site] = userid;
        }

    }
    else
    {
        //清除该用户占用位置的信息
        for (INT i = 1; i < MAX_VIDEOFRAME_NUM; i++)
        {
            if (m_iUserID[i] == userid)
            {
                m_iUserID[i] = -1;
                update();
                break;
            }
        }
    }
    return 0;
}
long MainWindow::OnGVClientLinkClose(WPARAM wParam, LPARAM lParam)
{

    for(INT i = 0; i < MAX_USER_NUM; i++)
    {
        m_iUserID[i] = -1;
        m_SelfId=-1;
    }
    AnyChatSDKLogin();
    return 0;
}

long MainWindow::RobotMessageEvent(DWORD dwMsg,LPCTSTR lpQuestionsStr,LPCTSTR lpAnswerStr,WPARAM wParm)
{
    switch (dwMsg) {
    case ROBOTTTSPLAYBACK:
    {
        std::string szlpAnswerStr=lpAnswerStr;
        long time=0;
        if(wParm==1)
            time=1;
        if(wParm==0)
            time=m_laudioplaytime/1000;
        bool isend=false;
        if(wParm==0||wParm==1)
            isend=true;
        emit ShowMessage(AI_Robot,szlpAnswerStr,isend,time,ASRstart);

    }
        break;
    case ROUSEROBOT:
        if(m_iUserID[1]!=-1)
        {
            //BRAC_UserCameraControl(m_iUserID[1], false);
            BRAC_UserSpeakControl(m_iUserID[1], false);
        }
        ChangeWinTOAI();
        m_bRobotIsExit=false;
        break;
    case EXITROBOT:
        if(m_iUserID[1]!=-1)
        {
            //BRAC_UserCameraControl(m_iUserID[1], TRUE);
            BRAC_UserSpeakControl(m_iUserID[1], TRUE);
        }
        ChangeWinTOVideo();
        m_bRobotIsExit=true;
        break;
    case ROBOTLISTEN:
        break;
    case ASRSENTTENCESTART:
    {
        std::string szQuestionsStr=lpQuestionsStr;
        emit ShowMessage(AI_User,szQuestionsStr,false,0,ASRstart);
        qDebug()<<"asrsentstart"<<lpQuestionsStr;
    }
        break;
    case ASRSENTTENCERUN:
    {
        std::string szQuestionsStr=lpQuestionsStr;
        emit ShowMessage(AI_User,szQuestionsStr,false,0,ASRRuning);
    }
        break;
    case ASRSENTTENCEEND:
    {
        std::string szQuestionsStr=lpQuestionsStr;
        emit ShowMessage(AI_User,szQuestionsStr,true,0,ASRStop);
        qDebug()<<"asrsentend:"<<lpQuestionsStr;
    }
    case ASRSENTTENCETIME:
    {
        std::string szQuestionsStr=lpQuestionsStr;
        emit ShowMessage(AI_User,szQuestionsStr,true,m_lAsktime>1000?m_lAsktime/1000:1,ASRComplete);
        qDebug()<<"asrsentend:"<<lpQuestionsStr;
    }
        break;
    default:
        break;
    }
    return 0;
}
void MainWindow::OnAnyChatCoreSDKEvent(DWORD dwEventType, LPCTSTR lpEventJsonStr, LPVOID lpUserValue)
{
    std::string logstr;
    logstr+="AIRobot:CoreSDKEvent:";
    logstr+=lpEventJsonStr;
    qDebug()<<logstr.c_str();
    MainWindow *pthis=static_cast<MainWindow*>(lpUserValue);
    if(dwEventType == ANYCHAT_CORESDKEVENT_AIABILITY){
        DWORD errcode=-1;
        DWORD aievent=0;
        DWORD aitype=0;
        if(lpEventJsonStr==NULL||!CJsonUtil::IsJson(lpEventJsonStr))
            return;
        if (CJsonUtil::IsJsonKeyExist((CHAR*)lpEventJsonStr,"aitype"))
        {
            CJsonUtil::GetIntValue((CHAR*)lpEventJsonStr,"aitype",aitype);
        }
        if(CJsonUtil::IsJsonKeyExist((CHAR*)lpEventJsonStr,"errorcode"))
            CJsonUtil::GetIntValue((CHAR*)lpEventJsonStr,"errorcode",errcode);
        if (CJsonUtil::IsJsonKeyExist((CHAR*)lpEventJsonStr,"aievent"))
        {

            CJsonUtil::GetIntValue((CHAR*)lpEventJsonStr,"aievent",aievent);
            if (aievent==1)
            {
                if (errcode==0)
                {
                    pthis->m_Aihelper.m_bAiRobotIsCreate=TRUE;
                    pthis->m_Aihelper.AIASRStart(0);
                }
                else
                {
                    pthis->m_Aihelper.m_bAirobotCreateErr=FALSE;
                }
            }

            pthis->AnalyzeResult(const_cast<char*>(lpEventJsonStr),aievent,aitype);

        }

        if (errcode==AC_ERROR_AI_ABILITY_ROBOTOFFLINE)
        {
            pthis->m_Aihelper.m_bAiRobotIsCreate=FALSE;
            pthis->m_Aihelper.m_bASRisStart=FALSE;//Asr是否开始
            pthis->m_Aihelper.AICreate();
        }

    }
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    if(m_Localeuserpalyer.IsInit())
        m_Localeuserpalyer.resize();
    if(m_RemoteUserplayer.IsInit())
        m_RemoteUserplayer.resize();
}
//视频回调数据绘制视频
void MainWindow::VideoData_CallBackEx(DWORD dwUserid, LPVOID lpBuf, DWORD dwLen, BITMAPINFOHEADER bmiHeader, DWORD dwTimeStamp, LPVOID lpUserValue)
{
    MainWindow *pThis = (MainWindow*)lpUserValue;

    if(pThis)
    {

        if(pThis->m_SelfId == (int)dwUserid)
        {
            if(!pThis->m_Localeuserpalyer.IsInit())
            {
                pThis->m_Localeuserpalyer.OpenRenderer((HWND)pThis->ui->LocalVideolabel->winId(),bmiHeader.biWidth,bmiHeader.biHeight);
            }
            pThis->m_Localeuserpalyer.AddVideoBuf((CHAR*)lpBuf,dwLen,bmiHeader.biWidth,bmiHeader.biHeight);
        }
        else
        {
            if(!pThis->m_RemoteUserplayer.IsInit())
            {
                pThis->m_RemoteUserplayer.OpenRenderer((HWND)pThis->ui->RemoteVideolabel->winId(),bmiHeader.biWidth,bmiHeader.biHeight);
            }
            pThis->m_RemoteUserplayer.AddVideoBuf((CHAR*)lpBuf,dwLen,bmiHeader.biWidth,bmiHeader.biHeight);
        }

    }
    return;
}
void MainWindow::AudioData_CallBackEx(DWORD dwUserid, LPVOID lpBuf, DWORD dwLen, WAVEFORMATEX waveFormatEx, DWORD dwTimeStamp, LPVOID lpUserValue)
{
    return;
}

void MainWindow::NotifyMessage_CallBack(DWORD dwNotifyMsg, DWORD wParam, DWORD lParam, LPVOID lpUserValue)
{
    MainWindow*	pAnyChatSDKProc = (MainWindow*)lpUserValue;
    if(!pAnyChatSDKProc)
        return;

    switch(dwNotifyMsg)
    {
    case WM_GV_CONNECT:				pAnyChatSDKProc->OnGVClientConnect(wParam,lParam);				break;
    case WM_GV_LOGINSYSTEM:			pAnyChatSDKProc->OnGVClientLogin(wParam,lParam);                break;
    case WM_GV_ENTERROOM:       	pAnyChatSDKProc->OnGVClientEnterRoom(wParam,lParam);            break;
    case WM_GV_MICSTATECHANGE:		pAnyChatSDKProc->OnGVClientMicStateChange(wParam,lParam);       break;
    case WM_GV_USERATROOM:			pAnyChatSDKProc->OnGVClientUserAtRoom(wParam,lParam);           break;
    case WM_GV_LINKCLOSE:       	pAnyChatSDKProc->OnGVClientLinkClose(wParam, lParam);           break;
    case WM_GV_ONLINEUSER:			pAnyChatSDKProc->OnGVClientOnlineUser(wParam,lParam);           break;

    case WM_GV_CAMERASTATE:			pAnyChatSDKProc->OnAnyChatCameraStateChgMessage(wParam,lParam);	break;
    case WM_GV_ACTIVESTATE:			pAnyChatSDKProc->OnAnyChatActiveStateChgMessage(wParam,lParam);	break;
    case WM_GV_P2PCONNECTSTATE:		pAnyChatSDKProc->OnAnyChatP2PConnectStateMessage(wParam,lParam);break;
    case WM_GV_SDKWARNING:			pAnyChatSDKProc->OnAnyChatSDKWarningMessage(wParam,lParam);     break;

    default:
        break;
    }
}
