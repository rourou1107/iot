#include "ac_jsonutils_rapid.h"

namespace AnyChat{
namespace Json{

Value::Value(void)	
: m_pDocument(new ac_rapidjson::Document),
  m_document(*m_pDocument)
{
	if(!m_document.IsObject())
		m_document.SetObject();
}

Value::Value(Value const& root)
: m_pDocument(new ac_rapidjson::Document),
  m_document(*m_pDocument)
{
	if(!m_document.IsObject())
		m_document.SetObject();
	std::string str = root.toStyledString();
	m_document.Parse(str.c_str());
}

Value::~Value(void)	
{
	if(m_pDocument)
	{
		delete m_pDocument;
		m_pDocument = NULL;
	}
}

ac_rapidjson::Document* Value::GetDocument(void)
{
	return m_pDocument;
}

// ��ȡ����
bool Value::Get(const char* json, const char* key, DWORD& value)
{
	Value acJson;
	if(!acJson.parse(json))
		return false;
	return acJson.Get(key, value);
}

// ��ȡ64λ����
bool Value::Get(const char* json, const char* key, INT64& value)
{
	Value acJson;
	if(!acJson.parse(json))
		return false;
	return acJson.Get(key, value);
}

// ��ȡdouble
bool Value::Get(const char* json, const char* key, DOUBLE& value)
{
	Value acJson;
	if(!acJson.parse(json))
		return false;
	return acJson.Get(key, value);
}

// ��ȡ�ַ���
bool Value::Get(const char* json, const char* key, char* value, DWORD size)
{
	Value acJson;
	if(!acJson.parse(json))
		return false;
	return acJson.Get(key, value, size);
}

// �Ƿ��г�Ա
bool Value::HasMember(const char* json, const char* key)
{
	Value acJson;
	if(!acJson.parse(json))
		return false;
	return acJson.GetDocument()->HasMember(key);
}

// �ϲ�
void Value::Merge(Value& root1, Value& root2)
{
	ac_rapidjson::Document* pDoc = root1.GetDocument();
	ac_rapidjson::Document* pDoc2 = root2.GetDocument();
	for(ac_rapidjson::Value::MemberIterator iter = pDoc2->MemberBegin(); iter != pDoc2->MemberEnd(); iter++)
	{
		const char* name = iter->name.GetString();
		if(pDoc->HasMember(name))
			pDoc->RemoveMember(name);
		ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
		keyobject.SetString(name, pDoc->GetAllocator());
		ac_rapidjson::Value value_copy;
		value_copy.CopyFrom(iter->value, pDoc->GetAllocator());     // ������ value_copy
		pDoc->AddMember(keyobject, value_copy, pDoc->GetAllocator());
	}
}

// �����ַ���
bool Value::parse(const char* lpString)
{
	if(!lpString)
		return false;
	m_document.Parse(lpString);
	return !m_document.HasParseError();
}

// ���json�ַ���
char* Value::toStyledString(char* lpOutBuffer, DWORD& dwOutSize)
{
	ac_rapidjson::StringBuffer buffer;	
	ac_rapidjson::Writer<ac_rapidjson::StringBuffer> writer(buffer);
	m_document.Accept(writer);
	if(lpOutBuffer && dwOutSize > buffer.GetSize())
	{
		_snprintf(lpOutBuffer, dwOutSize, "%s", buffer.GetString());
		lpOutBuffer[dwOutSize-1] = '\0';
	}
	dwOutSize = buffer.GetSize();
	return lpOutBuffer;
}

// ���json�ַ���
std::string Value::toStyledString()
{
	std::string str;
	ac_rapidjson::StringBuffer buffer;	
	ac_rapidjson::Writer<ac_rapidjson::StringBuffer> writer(buffer);
	m_document.Accept(writer);
	size_t size = buffer.GetSize();
	if(size)
	{
		str.resize(size + 1);
		CHAR* lpOutBuffer = (CHAR*)str.c_str();
		_snprintf(lpOutBuffer, size+1, "%s", buffer.GetString());
		lpOutBuffer[size] = '\0';
	}
	return str;
}

// ���json�ַ���
std::string Value::toStyledString() const
{
	std::string str;
	ac_rapidjson::StringBuffer buffer;	
	ac_rapidjson::Writer<ac_rapidjson::StringBuffer> writer(buffer);
	m_document.Accept(writer);
	size_t size = buffer.GetSize();
	if(size)
	{
		str.resize(size + 1);
		CHAR* lpOutBuffer = (CHAR*)str.c_str();
		_snprintf(lpOutBuffer, size+1, "%s", buffer.GetString());
		lpOutBuffer[size] = '\0';
	}
	return str;
}

// ���ӳ�Ա���ַ�����
void Value::Put(const char* key, const char* value)
{
	if(m_document.HasMember(key))
	{
		ac_rapidjson::Value & vobject = m_document[key];
		vobject.setAllocator(m_document.GetAllocatorPoint());
		vobject = value;
	}
	else
	{
		ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
		keyobject.SetString(key, m_document.GetAllocator());
		ac_rapidjson::Value vobject(ac_rapidjson::kStringType);
		vobject.SetString(value, m_document.GetAllocator());
		m_document.AddMember(keyobject, vobject, m_document.GetAllocator());
	}
}

// ���ӳ�Ա�����Σ�
void Value::Put(const char* key, DWORD value)
{
	if(m_document.HasMember(key))
	{
		ac_rapidjson::Value & vobject = m_document[key];
		vobject = (int)value;
	}
	else
	{
		ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
		keyobject.SetString(key, m_document.GetAllocator());
		ac_rapidjson::Value vobject(ac_rapidjson::kNumberType);
		vobject.SetInt(value);
		m_document.AddMember(keyobject, vobject, m_document.GetAllocator());
	}
}

// ���ӳ�Ա��64λ���Σ�
void Value::Put(const char* key, INT64 value)
{
	if(m_document.HasMember(key))
	{
		ac_rapidjson::Value & vobject = m_document[key];
		if(vobject.IsNumber())
		{
			vobject.SetInt64(value);
			return;
		}
		else
		{
			m_document.RemoveMember(key);
		}
	}
	ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
	keyobject.SetString(key, m_document.GetAllocator());
	ac_rapidjson::Value vobject(ac_rapidjson::kNumberType);
	vobject.SetInt64(value);
	m_document.AddMember(keyobject, vobject, m_document.GetAllocator());
}

// ���ӳ�Ա��DOUBLE��
void Value::Put(const char* key, DOUBLE value)
{
	if(m_document.HasMember(key))
	{
		ac_rapidjson::Value & vobject = m_document[key];
		if(vobject.IsNumber())
		{
			vobject.SetDouble(value);
			return;
		}
		else
		{
			m_document.RemoveMember(key);
		}
	}
	ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
	keyobject.SetString(key, m_document.GetAllocator());
	ac_rapidjson::Value vobject(ac_rapidjson::kNumberType);
	vobject.SetDouble(value);
	m_document.AddMember(keyobject, vobject, m_document.GetAllocator());
}

// ���ӳ�Ա��object)
void Value::Put(const char* key, Value & value)
{
	if(!value.m_document.IsObject())
		return;
	if(m_document.HasMember(key))
		m_document.RemoveMember(key);
	ac_rapidjson::Document::AllocatorType& a = m_document.GetAllocator();
	ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
	keyobject.SetString(key, a);
	ac_rapidjson::Value value_copy;
	value_copy.CopyFrom(value.m_document, a);     // ������ document ������ value_copy
	m_document.AddMember(keyobject, value_copy, a);
}

// ���ӳ�Ա������-���Σ�
void Value::Put(const char* key, int index, int value)
{
	if(!m_document.HasMember(key))
	{
		ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
		keyobject.SetString(key, m_document.GetAllocator());
		ac_rapidjson::Value arraybject(ac_rapidjson::kArrayType);
		arraybject.PushBack(value, m_document.GetAllocator());
		m_document.AddMember(keyobject, arraybject, m_document.GetAllocator());
	}
	else
	{
		ac_rapidjson::Value & contents = m_document[key];
		if(!contents.IsArray())
			assert(0);
		else
		{
			if(index < (int)contents.Size())
			{	
				ac_rapidjson::Value & v = contents[index];
				v.SetInt(value);
			}
			else
				contents.PushBack(value, m_document.GetAllocator());
		}
	}
}

// ���ӳ�Ա������-64λ���Σ�
void Value::Put(const char* key, int index, INT64 value)
{
	if(!m_document.HasMember(key))
	{
		ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
		keyobject.SetString(key, m_document.GetAllocator());
		ac_rapidjson::Value arraybject(ac_rapidjson::kArrayType);
		arraybject.PushBack(value, m_document.GetAllocator());
		m_document.AddMember(keyobject, arraybject, m_document.GetAllocator());
	}
	else
	{
		ac_rapidjson::Value & contents = m_document[key];
		if(!contents.IsArray())
			assert(0);
		else
		{
			if(index < (int)contents.Size())
			{	
				ac_rapidjson::Value & v = contents[index];
				v.SetInt64(value);
			}
			else
				contents.PushBack(value, m_document.GetAllocator());
		}
	}
}

// ���ӳ�Ա������-�ַ�����
void Value::Put(const char* key, int index, const char* value)
{
	if(!m_document.HasMember(key))
	{
		ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
		keyobject.SetString(key, m_document.GetAllocator());
		ac_rapidjson::Value data(ac_rapidjson::kStringType);
		data.SetString(value, m_document.GetAllocator());
		ac_rapidjson::Value arraybject(ac_rapidjson::kArrayType);
		arraybject.PushBack(data, m_document.GetAllocator());
		m_document.AddMember(keyobject, arraybject, m_document.GetAllocator());
	}
	else
	{
		ac_rapidjson::Value & contents = m_document[key];
		if(!contents.IsArray())
			assert(0);
		else
		{
			if(index < (int)contents.Size())
			{	
				ac_rapidjson::Value & v = contents[index];
				v.SetString(value, m_document.GetAllocator());
			}
			else
			{
				ac_rapidjson::Value data(ac_rapidjson::kStringType);
				data.SetString(value, m_document.GetAllocator());
				contents.PushBack(data, m_document.GetAllocator());
			}
		}
	}
}

// ���ӳ�Ա������-object��
void Value::Put(const char* key, int index, Value & value)
{
	if(!value.m_document.IsObject())
		return;
	ac_rapidjson::Document::AllocatorType& a = m_document.GetAllocator();
	ac_rapidjson::Value value_copy;
	value_copy.CopyFrom(value.m_document, a);     // ������ document ������ v2
	if(!m_document.HasMember(key))
	{
		ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
		keyobject.SetString(key, m_document.GetAllocator());
		ac_rapidjson::Value arraybject(ac_rapidjson::kArrayType);
		arraybject.PushBack(value_copy, m_document.GetAllocator());
		m_document.AddMember(keyobject, arraybject, a);
	}
	else
	{
		ac_rapidjson::Value & contents = m_document[key];
		if(!contents.IsArray())
			assert(0);
		else
		{
			if(index < (int)contents.Size())
			{	
				ac_rapidjson::Value & v = contents[index];
				v = value_copy;
			}
			else
				contents.PushBack(value_copy, m_document.GetAllocator());
		}
	}
}

// ��ȡ��Ա(�ַ���)
bool Value::Get(const char* key, char* value, DWORD size)
{
	bool ret = false;
	do 
	{
		if(!m_document.IsObject())
			break;
		if(!m_document.HasMember(key))
			break;
		if(m_document[key].IsString())	
		{								
			_snprintf(value, size, "%s", m_document[key].GetString());	
			value[size-1] = '\0';
			ret = true;
		}
	} while (false);
	return ret;
}

// ��ȡ��Ա(����)
bool Value::Get(const char* key, DWORD& value)
{
	bool ret = false;
	do 
	{
		if(!m_document.IsObject())
			break;
		if(!m_document.HasMember(key))
			break;
		if(m_document[key].IsNumber())
		{
			value = m_document[key].GetInt();
			ret = true;
			break;
		}
		if(m_document[key].IsString())	
		{								
			value = atoi(m_document[key].GetString());
			ret = true;
		}
	} while (false);
	return ret;
}

// ��ȡ��Ա(64λ����)
bool Value::Get(const char* key, INT64& value)
{
	bool ret = false;
	do 
	{
		if(!m_document.IsObject())
			break;
		if(!m_document.HasMember(key))
			break;
		if(m_document[key].IsNumber())
		{
			value = m_document[key].GetInt64();
			ret = true;
			break;
		}
	} while (false);
	return ret;
}

// ��ȡ��Ա(DOUBLE)
bool Value::Get(const char* key, DOUBLE& value)
{
	bool ret = false;
	do 
	{
		if(!m_document.IsObject())
			break;
		if(!m_document.HasMember(key))
			break;
		if(m_document[key].IsNumber())
		{
			value = m_document[key].GetDouble();
			ret = true;
			break;
		}
	} while (false);
	return ret;
}

// ��ȡ��Ա(����)
bool Value::GetArraySize(const char* key, DWORD& size)
{
	bool ret = false;
	do 
	{
		if(!m_document.IsObject())
			break;
		if(!m_document.HasMember(key))
			break;
		if(m_document[key].IsArray())
		{
			ac_rapidjson::Value & contents = m_document[key];
			size = contents.Size();
			ret = true;
			break;
		}
	} while (false);
	return ret;
}

// ��ȡ��Ա(����-����)
bool Value::Get(const char* key, int index, DWORD& value)
{
	bool ret = false;
	do 
	{
		if(!m_document.IsObject())
			break;
		if(!m_document.HasMember(key))
			break;
		if(m_document[key].IsArray())
		{
			ac_rapidjson::Value & contents = m_document[key];
			if(index >= (int)contents.Size())
				break;
			ac_rapidjson::Value & v = contents[index];
			if(v.IsNumber())
				value = v.GetInt();
			else if(v.IsString())
				value = atoi(v.GetString());
			else
				break;
			ret = true;
			break;
		}
	} while (false);
	return ret;
}

// ��ȡ��Ա(����-64λ����)
bool Value::Get(const char* key, int index, INT64& value)
{
	bool ret = false;
	do 
	{
		if(!m_document.IsObject())
			break;
		if(!m_document.HasMember(key))
			break;
		if(m_document[key].IsArray())
		{
			ac_rapidjson::Value & contents = m_document[key];
			if(index >= (int)contents.Size())
				break;
			ac_rapidjson::Value & v = contents[index];
			if(v.IsNumber())
				value = v.GetInt64();
			else
				break;
			ret = true;
			break;
		}
	} while (false);
	return ret;
}

// ��ȡ��Ա(����-�ַ���)
bool Value::Get(const char* key, int index, char* value, DWORD size)
{
	bool ret = false;
	do 
	{
		if(!m_document.IsObject())
			break;
		if(!m_document.HasMember(key))
			break;
		if(m_document[key].IsArray())
		{
			ac_rapidjson::Value & contents = m_document[key];
			if(index >= (int)contents.Size())
				break;
			ac_rapidjson::Value & v = contents[index];
			if(!v.IsString())
				break;
			_snprintf(value, size-1, "%s", v.GetString());
			value[size-1] = '\0';
			ret = true;
			break;
		}
	} while (false);
	return ret;
}

// ��ȡ��Ա(����-object)
bool Value::Get(const char* key, int index, Value & value)
{
	bool ret = false;
	do 
	{
		if(!m_document.IsObject())
			break;
		if(!m_document.HasMember(key))
			break;
		if(m_document[key].IsArray())
		{
			ac_rapidjson::Value & contents = m_document[key];
			if(index >= (int)contents.Size())
				break;
			ac_rapidjson::Value & v = contents[index];
			if(!v.IsObject())
				break;

			ac_rapidjson::StringBuffer buffer;	
			ac_rapidjson::Writer<ac_rapidjson::StringBuffer> writer(buffer);
			v.Accept(writer);
			value.parse(buffer.GetString());
			ret = true;
			break;
		}
	} while (false);
	return ret;
}

// ��ȡ��Ա(Object)
bool Value::Get(const char* key, Value & value)
{
	bool ret = false;
	do 
	{
		if(!m_document.IsObject())
			break;
		if(!m_document.HasMember(key))
			break;
		if(m_document[key].IsObject())
		{
			ac_rapidjson::Value & contents = m_document[key];
			ac_rapidjson::StringBuffer buffer;	
			ac_rapidjson::Writer<ac_rapidjson::StringBuffer> writer(buffer);
			contents.Accept(writer);
			value.parse(buffer.GetString());
			//ac_rapidjson::Value value_copy(contents, m_document.GetAllocator());          // ����һ����¡
			ret = true;
			break;
		}
	} while (false);
	return ret;
}

// �Ƴ���Ա
bool Value::removeMember(const char* key)
{
	if(m_document.HasMember(key))
	{
		return m_document.RemoveMember(key);
	}
	return true;
}

// �Ƿ��г�Ա
bool Value::HasMember(const char* key)
{
	return m_document.HasMember(key);
}
bool Value::isMember(const char* key)
{
	return HasMember(key);
}

// �Ƿ�Ϊ��
bool Value::empty(void)
{
	return (m_document.MemberBegin() == m_document.MemberEnd());
}

// ���
void Value::clear(void)
{
	m_document.Clear();
}

ac_rapidjson::Value& Value::operator[](const char* key)
{
	if(!m_document.HasMember(key))
	{
		ac_rapidjson::Value keyobject(ac_rapidjson::kStringType);
		ac_rapidjson::Value vobject(ac_rapidjson::kNullType);
		keyobject.SetString(key, m_document.GetAllocator());
		m_document.AddMember(keyobject, vobject, m_document.GetAllocator());
	}
	ac_rapidjson::Value& vobject = m_document[key];
	vobject.setAllocator(m_document.GetAllocatorPoint());
	return vobject;
}

Value& Value::operator=(Value const& root)
{
	std::string str = root.toStyledString();
	this->parse(str.c_str());
	return *this;
}

//////////////////////////////////////////////////////////////////////////
Reader::Reader(void)
{
}

Reader::~Reader(void)
{
}

// ����json
bool Reader::parse(const CHAR* json, Value& root)
{
	return root.parse(json);
}

}}
