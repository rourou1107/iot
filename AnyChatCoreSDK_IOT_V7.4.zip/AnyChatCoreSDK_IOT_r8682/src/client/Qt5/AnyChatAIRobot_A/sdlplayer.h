/**************************************************************

  * brief:
  * author:wu
  * date: 2019-09-26
  * description:   sdl打开Openplayer　和draw函数要在同一个线程使用如果不是同线程，无法正常绘图到控件上。
  *
***************************************************************/
#ifndef SDLPLAYER_H
#define SDLPLAYER_H
#include "GVSDK.h"
#include <queue>
#include<atomic>
#include"acthread.h"
extern "C"
{
#include<SDL2/SDL.h>
}
#define SDL_ERR_SUCCESS 0 //
#define SDL_ERR_CREATEWINDOW_FAILED 1 //创建窗口错误
#define SDL_ERR_CREATERERENDERER_FAILED 2 //创建渲染器失败
#define SDL_ERR_CREATETEXTURE_FAILED 3 //创建纹理失败
#define SDL_ERR_RENDERCLEAR_FAILED 4  //清理渲染器失败
#define SDL_ERR_RENDERCOPY_FAILED 5   //复制数据纹理给渲染器失败
#define SDL_ERR_NOTINIT 6 //没有初始化

#pragma pack(1)
typedef struct tagVIDEODATAPACK
{
    DWORD dwWidth;
    DWORD dwHeight;
    CHAR  *lpVideoDataBuf;
    DWORD dwVideoDataSize;
    tagVIDEODATAPACK()
    {
        dwWidth=0;
        dwHeight=0;
        lpVideoDataBuf=NULL;
        dwVideoDataSize=0;
    }

}VIDEODATAPACK,*LPVIDEODATAPACK;
#pragma pack()
class SdlPlayer
{
public:
    SdlPlayer();
    ~SdlPlayer();
    DWORD OpenRenderer(HWND hwnd,DWORD dwWidth,DWORD dwHeight);
    DWORD AddVideoBuf(CHAR * lpBuf,DWORD Buflen,DWORD dwWidth,DWORD dwHeight);
    DWORD CloseRenderer();
    BOOL IsInit(){return m_bIsinit;}
    BOOL resize(){m_bresize=TRUE;return m_bresize; }
    BOOL            m_bresize=FALSE;
    static DWORD SdlInit();
    static DWORD SdlRelease();
    static ac_thread_result_t Run(void *args);
private:
    SDL_Window *    m_screen=NULL;
    SDL_Renderer *  m_sdlRenderer=NULL;
    SDL_Texture *   m_sdlTexture=NULL;
    HWND            m_hwnd=NULL;
    DWORD           m_errcode=SDL_ERR_SUCCESS;
    DWORD           m_dwWidth=-1;
    DWORD           m_dwHeight=-1;
    unsigned long   m_lutid=0;
    BOOL            m_bIsinit=FALSE;
    BOOL            m_bIsRun=FALSE;
    ac_thread_t     m_rendererthread;
    ac_thread_mutex_t m_renderermutex;
    ac_thread_cond_t m_renderercond;
    std::queue<VIDEODATAPACK> m_VideoDataQueue;
    DWORD CreateSdlRenderer();
    DWORD Draw(VIDEODATAPACK &Videodata);
    DWORD CloseSDLRenderer();

};

#endif // SDLPLAYER_H
