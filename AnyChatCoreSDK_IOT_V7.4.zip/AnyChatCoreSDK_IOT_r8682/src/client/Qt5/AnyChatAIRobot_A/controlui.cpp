#include "controlui.h"
#include "QTimer"
controlUI::controlUI()
{
    m_ai = new AI();
    m_mainwindow = new MainWindow ();
}


int controlUI::ShowVideoWin()
{
    m_ai->hide();
    m_mainwindow->show();
    return 0;
}


int controlUI::ShowAiWin()
{
    m_mainwindow->hide();
    m_ai->show();
    return 0;
}

int controlUI::GetHandle(QLabel *label, int HandleType)
{
    if(HandleType == Handle_type_Retome||HandleType == Handle_type_Locate)
    {
        //int GetHandle_VideoWin(QLabel &label, int HandleType);
        m_mainwindow->GetHandle_VideoWin(label,HandleType);
    }


    return 0;
}

