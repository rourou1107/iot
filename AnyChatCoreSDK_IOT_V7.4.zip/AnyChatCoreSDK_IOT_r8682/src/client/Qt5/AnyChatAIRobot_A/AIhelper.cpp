#include"AIhelper.h"
#include<time.h>
#if defined(WIN32)
#include"jsonutils.h"
#else
#	include <uuid/uuid.h>			// need link -luuid
#endif

AIhelper::AIhelper()
{
    m_GRobootGuid[128]={0};
    m_GTTStaskid[128]={0};
    m_GAsrTaskid[128]={0};
    m_bAiRobotIsCreate=FALSE;
    m_bAirobotCreateErr=FALSE;
    m_bASRisStart=FALSE;


}
void AIhelper::uuid_conver(char* source,char* desc)
{
    int i,j;
    for(i = 0,j= 0;i < 36;i++,j++){
        if(desc[i]=='-'){
            source[j]=desc[i];
        }
        else
            source[j] = toupper(desc[i]);
    }
    source[j] = '\0';
}
int AIhelper::AICreate()
{

    if (!m_bAiRobotIsCreate)
    {
#if defined(WIN32)
        GUID guid=CGuidUtils::CreateGuid();
        CGuidUtils::GuidToString(guid,m_GRobootGuid,sizeof(m_GRobootGuid));
#else
        uuid_t uuid;
        uuid_generate(uuid);
        uuid_unparse(uuid, m_GRobootGuid);
        char uuidstr[128];
        uuid_t uuidt;
        uuid_generate(uuidt);
        uuid_unparse(uuidt, uuidstr);
        char buff[40];
        uuid_conver(buff,uuidstr);
        sprintf(m_GRobootGuid,"%s",buff);
#endif

    }

    std::string strJson;
    strJson +="{\r\n\"cmd\":1,\t\n";
    strJson +="\"robotid\":\"";
    strJson+=m_GRobootGuid;
    strJson+="\"\r\n}";
    DWORD ret=0;
    CHAR szResultBuf[1024] = {0};
    ret=BRAC_SDKControl(ANYCHAT_SDKCTRL_AIABILITY, const_cast<CHAR*>(strJson.c_str()),szResultBuf,sizeof(szResultBuf));

    std::string logstr;
    logstr+="AICreate:ret";
    char intbuffer[10];
    sprintf(intbuffer,"%d",ret);
    logstr+=intbuffer;
    logstr+= "szResultBuf:";
    logstr+= szResultBuf;
    logstr+="send:";
    logstr+=strJson;
    BRAC_SetSDKOption(BRAC_SO_CORESDK_WRITELOG,logstr.c_str(),logstr.length());
    return 0;
}

int AIhelper::AIRelease()
{
    std::string strJson;
    strJson +="{\"cmd\":2,\r\n";
    strJson +="\"robotid\":\"";
    strJson+=m_bAiRobotIsCreate==TRUE?m_GRobootGuid:"������û�д���";
    strJson+="\"}";
    DWORD ret=0;
    CHAR szResultBuf[1024] = {0};
    ret=BRAC_SDKControl(ANYCHAT_SDKCTRL_AIABILITY, const_cast<CHAR*>(strJson.c_str()),szResultBuf,sizeof(szResultBuf));
    m_bAiRobotIsCreate=FALSE;


    std::string logstr;
    logstr+="AIRelease:ret";
    char intbuffer[10];
    sprintf(intbuffer,"%d",ret);
    logstr+=intbuffer;
    logstr+= "szResultBuf:";
    logstr+= szResultBuf;
    logstr+="send:";
    logstr+=strJson;
    BRAC_SetSDKOption(BRAC_SO_CORESDK_WRITELOG,logstr.c_str(),logstr.length());
    return 0;
}

int AIhelper::AITTS(int TTSmode,char* content,int istest)
{
    char szuuid[128] = {0};
#if defined(WIN32)
    GUID guid=CGuidUtils::CreateGuid();
    CGuidUtils::GuidToString(guid,szuuid,sizeof(szuuid));
#else
    char buff[40];
    uuid_t uuid;
    uuid_generate(uuid);
    uuid_unparse(uuid, buff);

    uuid_conver(szuuid,buff);
#endif

    std::string strJson;
    char strint[10];

    strJson +="{";
    strJson+="\"testmode\":";
    char intbuffer[10];
    sprintf(intbuffer,"%d",istest);
    strJson+=intbuffer;
    strJson+=",";
    strJson+="\"cmd\":4,\r\n";
    strJson +="\"aitype\":2,\r\n";
    strJson +="\"taskid\":\"";
    strJson+=szuuid;
    strJson+="\",\r\n";
    strJson +="\"ttstype\":2,\r\n";
    strJson +="\"mode\":";
    sprintf(strint,"%d",TTSmode);
    strJson+=strint;
    strJson+=",\r\n";
    strJson +="\"robotid\":\"";
    strJson+=m_bAiRobotIsCreate?m_GRobootGuid:"������û�д���";
    strJson+="\",\r\n";
    strJson +="\"content\":\"";
    strJson+=content;
    strJson+="\"}\r\n";
    DWORD ret=0;
    CHAR szResultBuf[1024] = {0};
    ret=BRAC_SDKControl(ANYCHAT_SDKCTRL_AIABILITY, const_cast<CHAR*>(strJson.c_str()),szResultBuf,sizeof(szResultBuf));

    std::string logstr;
    logstr+="AITTS:ret";
    sprintf(intbuffer,"%d",ret);
    logstr+=intbuffer;
    logstr+= "szResultBuf:";
    logstr+= szResultBuf;
    logstr+="send:";
    logstr+=strJson;
    BRAC_SetSDKOption(BRAC_SO_CORESDK_WRITELOG,logstr.c_str(),logstr.length());

    return 0;
}

int AIhelper::AIASRStart(int istest)
{

    if (!m_bASRisStart)
    {
#if defined(WIN32)
        GUID tsakid=CGuidUtils::CreateGuid();
        CGuidUtils::GuidToString(tsakid,m_GAsrTaskid,sizeof(m_GAsrTaskid));
#else
        char uuidstr[128]={0};
        uuid_t uuid;
        uuid_generate(uuid);
        uuid_unparse(uuid, uuidstr);
        uuid_conver(m_GAsrTaskid,uuidstr);
#endif
    }
    else
    {
        AIASREnd();
#if defined(WIN32)
        sleep(100);
#else
        usleep(100*1000);
#endif

    }
    std::string strJson;
    strJson +="{";
    strJson+="\"testmode\":";
    char intbuffer[10];
    sprintf(intbuffer,"%d",istest);
    strJson+=intbuffer;
    strJson+=",";
    strJson+="\"cmd\":4,\r\n";
    strJson +="\"aitype\":1,\r\n";
    strJson +="\"taskid\":\"";
    strJson+=m_GAsrTaskid;
    strJson+="\",\r\n";
    strJson +="\"start\":1,\r\n";
    strJson+="\"flags\":1,\r\n";
    strJson +="\"timeinterval\":500,\r\n";
    strJson +="\"silencetime\":200,\r\n";
    strJson +="\"robotid\":\"";
    strJson +=m_bAiRobotIsCreate==TRUE? m_GRobootGuid:"������û�д���";
    strJson+="\"\r\n}";
    DWORD ret=0;
    CHAR szResultBuf[1024] = {0};
    ret=BRAC_SDKControl(ANYCHAT_SDKCTRL_AIABILITY, const_cast<CHAR*>(strJson.c_str()),szResultBuf,sizeof(szResultBuf));
    if (ret==0)
    {
        m_bASRisStart=TRUE;
    }



    std::string logstr;
    logstr+="AIASRStart:ret";
    sprintf(intbuffer,"%d",ret);
    logstr+=intbuffer;
    logstr+= "szResultBuf:";
    logstr+= szResultBuf;
    logstr+="send:";
    logstr+=strJson;
    BRAC_SetSDKOption(BRAC_SO_CORESDK_WRITELOG,logstr.c_str(),logstr.length());
    return 0;
}

int AIhelper::AIASREnd()
{
    std::string strJson;
    strJson +="{\"cmd\":4,\r\n";
    strJson +="\"aitype\":1,\r\n";
    strJson +="\"taskid\":\"";
    strJson+=m_bASRisStart==TRUE?m_GAsrTaskid:"ASRû�п�ʼ";
    strJson+="\",\r\n";
    strJson +="\"start\":0,\r\n";
    strJson +="\"timeinterval\":500,\r\n";
    strJson +="\"robotid\":\"";
    strJson+=m_bAiRobotIsCreate?m_GRobootGuid:"������û�д���";
    strJson+="\"}\r\n";
    DWORD ret=0;
    CHAR szResultBuf[1024] = {0};
    ret=BRAC_SDKControl(ANYCHAT_SDKCTRL_AIABILITY, const_cast<CHAR*>(strJson.c_str()),szResultBuf,sizeof(szResultBuf));
    if (ret==0)
    {
        m_bASRisStart=FALSE;
    }


    std::string logstr;
    logstr+="AIASREnd:ret";
    char intbuffer[10];
    sprintf(intbuffer,"%d",ret);
    logstr+=intbuffer;
    logstr+= "szResultBuf:";
    logstr+= szResultBuf;
    logstr+="send:";
    logstr+=strJson;
    BRAC_SetSDKOption(BRAC_SO_CORESDK_WRITELOG,logstr.c_str(),logstr.length());
    return 0;
}


