#ifndef CJSONUTIL_H
#define CJSONUTIL_H
#include "rapidjson/document.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/stringbuffer.h"

using namespace rapidjson;

class CJsonUtil
{
public:
    CJsonUtil(){}
    virtual ~CJsonUtil(){}

    // 从Json字符串取整型参数值
    static void GetIntValue(const char* szJsonBuf, const char* lpKey, unsigned int& iValue)
    {

        try {
            Document document;
            document.Parse(szJsonBuf);
            if(!document[lpKey].IsInt())
                return;
            iValue=document[lpKey].GetInt();
        } catch(...) {

        }
    }
    // 从Json字符串取字符串参数值
    static void GetStrValue(const char* szJsonBuf, const char* lpKey, char* szValue, unsigned int dwBufSize)
    {


        try {
            Document document;
            document.Parse(szJsonBuf);
            if(!document[lpKey].IsString())
                return;
            snprintf(szValue, dwBufSize, "%s", document[lpKey].GetString());
            szValue[dwBufSize-1] = '\0';
        } catch(...) {

        }

    }
    static int GetStringLength(const char* szJsonBuf, const char* lpKey)
    {
        int length=0;
        try {
            Document document;
            document.Parse(szJsonBuf);
            if(!document[lpKey].IsString())
                return length;
            length=  document[lpKey].GetStringLength();
        } catch(...) {

        }
        return length;
    }
    // 判断指定json key字段是否存在
    static bool IsJsonKeyExist(const char* pJsonBuf, const char* pJsonKey)
    {
        bool bIsExist = false;
        try{
            Document document;
            document.Parse(pJsonBuf);
            Value::ConstMemberIterator itr=document.FindMember(pJsonKey);
            if(itr !=document.MemberEnd())
                bIsExist=true;
        }
        catch(...){

        }

        return bIsExist;
    }
    //判断是否是json
    static bool IsJson(const char* pJsonBuf)
    {
        Document document;
        document.Parse(pJsonBuf);
        return document.IsObject();
    }

};

#endif // CJSONUTIL_H
