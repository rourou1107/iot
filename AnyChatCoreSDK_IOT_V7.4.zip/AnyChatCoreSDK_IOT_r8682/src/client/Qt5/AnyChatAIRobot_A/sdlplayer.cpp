#include "sdlplayer.h"
#include"QWidget"
static std::atomic_bool g_SDLIsInit(false);
SdlPlayer::SdlPlayer()
{
    ac_thread_mutex_init(&m_renderermutex,NULL);
    ac_thread_cond_init(&m_renderercond,NULL);
}

SdlPlayer::~SdlPlayer()
{
    if(m_bIsRun)
        CloseRenderer();
    ac_thread_mutex_destroy(&m_renderermutex);
    ac_thread_cond_destroy(&m_renderercond);
}


DWORD SdlPlayer::OpenRenderer(HWND hwnd, DWORD dwWidth, DWORD dwHeight)
{
    if(m_bIsRun)
        CloseRenderer();
    m_hwnd=hwnd;
    m_dwWidth=dwWidth;
    m_dwHeight=dwHeight;
    m_bIsRun=TRUE;
    ac_thread_create(&m_rendererthread,NULL,Run,(void*)this);
    {
        CAnyChatAutoLock autolock(m_renderermutex);
        ac_thread_cond_wait(&m_renderercond,&m_renderermutex);
    }
    if (m_errcode!=SDL_ERR_SUCCESS)
    {
        CloseRenderer();
    }
    return m_errcode;
}

DWORD SdlPlayer::AddVideoBuf(CHAR * lpBuf,DWORD Buflen,DWORD dwWidth,DWORD dwHeigh)
{
    if (!m_bIsRun)
        return -1;
    VIDEODATAPACK dataInfo;//实例化缓存结构体
    char* pBuf = new char[Buflen];//分配Buflen的缓存空间
    //缓存推送到队列
    memcpy(pBuf, lpBuf, Buflen);//数据拷贝到缓存中
    dataInfo.lpVideoDataBuf = pBuf;
    dataInfo.dwVideoDataSize = Buflen;
    dataInfo.dwWidth=dwWidth;
    dataInfo.dwHeight=dwHeigh;
    {
        CAnyChatAutoLock autolock(m_renderermutex);
        m_VideoDataQueue.push(dataInfo);
    }
    return 0;
}

DWORD SdlPlayer::CloseRenderer()
{
    m_bIsRun=FALSE;
    ac_thread_join(m_rendererthread,NULL);
    return 0;
}

DWORD SdlPlayer::SdlInit()
{
    if(SDL_Init(SDL_INIT_VIDEO))
    {
        printf( "Could not initialize SDL - %s\n", SDL_GetError());
        return -1;
    }
    g_SDLIsInit=TRUE;
    return 0;
}


DWORD SdlPlayer::SdlRelease()
{
    if (g_SDLIsInit)
    {
        SDL_Quit();
        g_SDLIsInit=FALSE;
    }
    return 0;
}

ac_thread_result_t SdlPlayer::Run(void *args)
{
    SdlPlayer *p_this=(SdlPlayer*)args;
    {
        if(p_this->CreateSdlRenderer()!=0)
        {
            CAnyChatAutoLock autolock(p_this->m_renderermutex);
            ac_thread_cond_signal(&p_this->m_renderercond);
            return NULL;
        }
        CAnyChatAutoLock autolock(p_this->m_renderermutex);
        ac_thread_cond_signal(&p_this->m_renderercond);
    }

    VIDEODATAPACK videotemp;
    bool isempty=true;
    while (p_this->m_bIsRun)
    {
        {
            CAnyChatAutoLock autolock(p_this->m_renderermutex);
            do{
                if(p_this->m_VideoDataQueue.empty())
                {
                    isempty=true;
                    break;
                }
                isempty=false;
                videotemp=p_this->m_VideoDataQueue.front();
                p_this->m_VideoDataQueue.pop();
            }while(false);
        }
        if(isempty)
        {
            usleep(1000*3);
            continue;
        }

        p_this->Draw(videotemp);

        if(videotemp.lpVideoDataBuf)
        {
            delete[] videotemp.lpVideoDataBuf;
            videotemp.lpVideoDataBuf=NULL;
        }
    }
    {
        CAnyChatAutoLock autolock(p_this->m_renderermutex);
        while(!p_this->m_VideoDataQueue.empty())
        {
            videotemp=p_this->m_VideoDataQueue.front();
            if(videotemp.lpVideoDataBuf)
            {
                delete[] videotemp.lpVideoDataBuf;
                videotemp.lpVideoDataBuf=NULL;
            }
            p_this->m_VideoDataQueue.pop();
        }
        p_this->CloseSDLRenderer();
    }
    return NULL;
}

DWORD SdlPlayer::CreateSdlRenderer()
{
    DWORD ret=SDL_ERR_SUCCESS;
    do{
        if(!m_screen)
        {
            m_screen=SDL_CreateWindowFrom(m_hwnd);
        }

        if(m_screen==NULL)
        {
            printf( "Could not SDL_CreateWindowFrom SDL - %s\n", SDL_GetError());
            ret=SDL_ERR_CREATEWINDOW_FAILED;
            m_errcode=SDL_ERR_CREATEWINDOW_FAILED;
            break;
        }
        if(!m_sdlRenderer)
            m_sdlRenderer = SDL_CreateRenderer(m_screen, -1, SDL_RENDERER_ACCELERATED);
        if(m_sdlRenderer==NULL)
        {
            CloseSDLRenderer();
            printf( "Could not SDL_CreateRenderer SDL - %s\n", SDL_GetError());
            ret=SDL_ERR_CREATERERENDERER_FAILED;
            m_errcode=SDL_ERR_CREATERERENDERER_FAILED;
            break;
        }
        m_sdlTexture = SDL_CreateTexture(m_sdlRenderer,SDL_PIXELFORMAT_IYUV, SDL_TEXTUREACCESS_STREAMING,m_dwWidth,m_dwHeight);
        if(m_sdlTexture==NULL)
        {
            CloseSDLRenderer();
            printf("Could not SDL_CreateTexture SDL - %s\n", SDL_GetError());
            ret=SDL_ERR_CREATETEXTURE_FAILED;
            m_errcode=SDL_ERR_CREATETEXTURE_FAILED;
            break;
        }
        m_bIsinit=TRUE;
    }
    while(FALSE);
    return ret;
}

DWORD SdlPlayer::Draw(VIDEODATAPACK &Videodata)
{
    DWORD ret=SDL_ERR_SUCCESS;
    do
    {
        if(m_bresize)
        {
            QWidget *widget= QWidget::find((WId)m_hwnd);
            SDL_SetWindowSize(m_screen,widget->width(),widget->height());
            m_bresize=FALSE;
        }
        if(Videodata.dwWidth!=m_dwWidth||Videodata.dwHeight!=m_dwHeight)
        {

            if(m_sdlTexture)
            {
                SDL_DestroyTexture(m_sdlTexture);
                m_sdlTexture=NULL;
            }
            m_sdlTexture = SDL_CreateTexture(m_sdlRenderer,SDL_PIXELFORMAT_IYUV, SDL_TEXTUREACCESS_STREAMING,Videodata.dwWidth,Videodata.dwHeight);
            if(m_sdlTexture==NULL)
            {
                printf( "Could not upadta SDL_CreateTexture SDL - %s\n", SDL_GetError());
                ret=SDL_ERR_CREATETEXTURE_FAILED;
                m_errcode=SDL_ERR_CREATETEXTURE_FAILED;
                break;
            }
            m_dwWidth=Videodata.dwWidth;
            m_dwHeight=Videodata.dwHeight;
            m_bresize=FALSE;
        }
        if(!m_sdlTexture||!m_sdlRenderer)
        {
            ret=SDL_ERR_NOTINIT;
            m_errcode=SDL_ERR_NOTINIT;
            break;
        }
        //更新纹理数据
        SDL_UpdateTexture( m_sdlTexture, NULL, Videodata.lpVideoDataBuf, Videodata.dwWidth);
        //清空渲染器
        if(-1==SDL_RenderClear(m_sdlRenderer))
        {
            printf("Could not SDL_RenderClear err - %s\n", SDL_GetError());
            ret=SDL_ERR_RENDERCLEAR_FAILED;
            m_errcode=SDL_ERR_RENDERCLEAR_FAILED;
            break;
        }
        //复制数据纹理给渲染器
        if(SDL_RenderCopy( m_sdlRenderer, m_sdlTexture,NULL,NULL)==-1)
        {
            printf( "Could not SDL_RenderCopy err - %s \e[0;31m \n", SDL_GetError());
            ret=SDL_ERR_RENDERCOPY_FAILED;
            m_errcode=SDL_ERR_RENDERCOPY_FAILED;
            break;
        }
        //显示
        SDL_RenderPresent(m_sdlRenderer);

    }
    while (FALSE) ;
    return ret;
}

DWORD SdlPlayer::CloseSDLRenderer()
{
    m_bIsinit=FALSE;
    if(g_SDLIsInit)
    {
        if(m_sdlTexture!=NULL)
        {
            SDL_DestroyTexture(m_sdlTexture);
            m_sdlTexture=NULL;
        }
        if(m_sdlRenderer!=NULL)
        {
            SDL_DestroyRenderer(m_sdlRenderer);
            m_sdlRenderer=NULL;
        }
        if(m_screen!=NULL)
        {
            SDL_DestroyWindow(m_screen);
            m_screen=NULL;
        }
    }
    return 0;
}
