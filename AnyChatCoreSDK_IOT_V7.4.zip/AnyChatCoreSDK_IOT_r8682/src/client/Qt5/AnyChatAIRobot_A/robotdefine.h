#ifndef ROBOTDEFINE_H
#define ROBOTDEFINE_H

#include <QLabel>
#include <QTimer>
enum AIMESSAGETYPE
{
    AI_Robot = 0,
    AI_User = 1
};
#pragma pack(1)
typedef struct tagAIObject
{
    QLabel *HeadIcon;//头像控件
    QLabel *ASRIcon;//ASR图标控件
    QLabel *TimeIcon;//时间控件
    QLabel *TextEdit;//文本显示控件
    QTimer *timer;//定时器
    AIMESSAGETYPE type;//类型AI_Robot,AI_User
    int TableWidgetRowNum_AIObject;//句柄和显示行数绑定
}AIObject,*LPAIObject;
#pragma pack()

//AI界面，当前显示的状态
enum
{
    RobotBroadcasting = 0,//机器人播报中
    Waiting = 1,//等待中
    InUserVoice //用户语音中
};


enum
{
    ASRRuning = 0,//ASR录音中
    ASRstart = 1,//ASR开始
    ASRStop = 2 ,//ASR停止
    ASRComplete = 3 //ASR直接显示内容和时间，不启动定时器
};

#define ROUSEROBOTSTR "你好"
#define EXITROBOTSTR  "退出"


#define ROBOTTTSPLAYBACK 1
#define ROUSEROBOT       2
#define EXITROBOT        3
#define ROBOTLISTEN      4
#define ASRSENTTENCESTART 5
#define ASRSENTTENCEEND  6
#define ASRSENTTENCERUN  7
#define ASRSENTTENCETIME 8

#endif // ROBOTDEFINE_H
