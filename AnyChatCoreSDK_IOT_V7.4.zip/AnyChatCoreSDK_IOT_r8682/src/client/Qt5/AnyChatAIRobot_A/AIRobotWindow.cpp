#include "AIRobotWindow.h"
#include "ui_AIRobotWindow.h"
#include <QFont>
#include <QApplication>
#include <QScrollBar>


#define TotaltableWidgetRowNum 10
#define AIIconwidget    34
#define AIIconheight    34
#define ColumnWidth_Edge 25
#define ColumnWidth_Head_ASR 38
#define GifSpace 500


#ifndef WIN32
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#endif

AIRobotWindow::AIRobotWindow(QWidget *parent) :
        QMainWindow(parent),
        ui(new Ui::AIRobotWindow)
{

    ui->setupUi(this);

    IsInitTableWidget = false;
    PlayComplete = true;
    m_giflabelASR = nullptr;
    m_timerPlay_Robbt = new QTimer(this);
    m_timerPlay_User = new QTimer(this);
    m_timer_gif = new QTimer(this);
    m_timerUserRecord = new QTimer(this);
    m_type = AI_Robot;
    m_Playgifname_robot = 1;
    m_Playgifname_User = 4;
    time_num_robot = 0;
    time_num_user = 0;
    m_state = RobotBroadcasting;
    m_timer_gif_num = 10000;
    RobotGifRun = false;

    m_labelUserRecordtime = nullptr;
    m_timeUserRecordtime = 0;

    m_IsLowPerformance = initLowPerformance();

    connect(m_timer_gif,SIGNAL(timeout()),this,SLOT(RobotGif()));
    connect(m_timerPlay_Robbt,SIGNAL(timeout()),this,SLOT(Inplay_Robot()));
    connect(m_timerPlay_User,SIGNAL(timeout()),this,SLOT(Inplay_User()));
    connect(m_timerUserRecord,SIGNAL(timeout()),this,SLOT(UpdateUserRecordtime()));
    m_iUserMessgeHandle=-1;
    m_iRobotMessageHandle=-1;
    m_ShowContentRunningNum = 0;
}


AIRobotWindow::~AIRobotWindow()
{
    delete ui;
    clearAIObject();
}

int AIRobotWindow::ShowMessage(AIMESSAGETYPE type, string szMessage,bool isEnd, int time, int asrtimer)
{
    int res=-1;
    do{

        int messagehandle=-1;
        if(type==AI_User)
        {
            if(m_iUserMessgeHandle==-1)
                m_iUserMessgeHandle=ApplyHandle(AI_User);
            messagehandle=m_iUserMessgeHandle;
        }
        else if(type==AI_Robot)
        {
            if(m_iRobotMessageHandle==-1)
                m_iRobotMessageHandle=ApplyHandle(AI_Robot);
            messagehandle=m_iRobotMessageHandle;
        }
        if(messagehandle==-1)
            break;
        ShowContent(messagehandle,szMessage,time,asrtimer);
        if(isEnd)
        {
            if(type==AI_User)
                m_iUserMessgeHandle=-1;
            else
                m_iRobotMessageHandle=-1;
        }

        res=0;
    }
    while(false);
    return res;
}

int AIRobotWindow::InitTableWidget()
{
    //只执行一次初始化,使用标志位判断是否有进行初始化过
    if(IsInitTableWidget)
    {
        return 0;
    }
    IsInitTableWidget=true;
    return 0;
}

//接口：申请一个显示位置，返回一个句柄
int AIRobotWindow::ApplyHandle(AIMESSAGETYPE type)
{
    if(!IsInitTableWidget)
    {
        InitTableWidget();
        if(this->IsLowPerformance())
        {
            RobotGif();   //低性能情况下，只贴一张静态图片
        }
        else
        {
            m_timer_gif->start(30);  //高性能机器情况下才开启动图刷新
        }
		m_CurrentPosition = ui->widget->y()+10;
    }

    if((m_CurrentPosition > (ui->widget->y() + ui->widget->height()/2 )) && (m_ShowContentRunningNum == 0))
    {
        clearAIObject();
        m_CurrentPosition = ui->widget->y()+10;
    }
    int handlefn = AIObjectVector.size();
    AIObject * p = new AIObject();
    p->HeadIcon = new QLabel(this);
    p->ASRIcon = new QLabel(this);
    p->TimeIcon = new QLabel(this);
    p->TextEdit = new QLabel(this);
    p->type = type;

    AIObjectVector.push_back(p);
    qDebug()<<"ApplyHandle  end  type = "<<type;
    return handlefn;
}


//用于显示
/*需要新增功能，如果上一个对象还没有播放完毕，就打断了，
 *那么需要定制定时器的刷新，并且把上一个对象的ASR图标设置为暂停。
*/
int AIRobotWindow::ShowContent(int handle,string& textContent,int time , int ASRTimer)
{
    m_ShowContentRunningNum+= 1;
    int ret = 0;

    int widget_x = ui->widget->x();
    int widget_width = ui->widget->width();

    AIObject *p = AIObjectVector[handle];


    do
    {
        if(!p)
        {
            ret = -1;
            break;
        }


        if(p->type == AI_Robot)
        {
            qDebug()<<"p->type = "<<p->type;
            //如果未结束播放，则需要打断。
            if(PlayComplete == false)
            {
                Interruptplay(m_type);
            }
            //插入头像
            if(p->HeadIcon)
            {
                p->HeadIcon->setStyleSheet("border-image: url(:/image/AI.png)");
                p->HeadIcon->setGeometry (widget_x+ColumnWidth_Edge, m_CurrentPosition+ColumnWidth_Edge, ColumnWidth_Head_ASR, ColumnWidth_Head_ASR);
            }
            else
            {
               ret = -1;
               break;
            }


            //ASR小喇叭图标，底色改为绿色，边框设置左边圆形，开启定时器
            if(p->ASRIcon)
            {
                  p->ASRIcon->setStyleSheet("border-top-left-radius:7px;border-bottom-left-radius :7px;border-image:url("");background-color: rgb(91,229,107)");
                p->ASRIcon->setGeometry(p->HeadIcon->x()+p->HeadIcon->width()+2,p->HeadIcon->y(),ColumnWidth_Head_ASR,ColumnWidth_Head_ASR);
                m_giflabelASR = p->ASRIcon;
            }
            else
            {
               ret = -1;
               break;
            }
            //time为0,则是播报中，time不为0，则是播报完毕，这是因为云端返回的PCM播放完才能知道长度。
            if(0 == time)
            {
                m_Playgifname_robot = 1;
                m_timerPlay_Robbt->start(GifSpace);//小喇叭图标播放
                m_state = RobotBroadcasting;
                SwitchGifState(m_state);
                if(this->IsLowPerformance())
                {
                    RobotGif();   //低性能情况下，只贴一张静态图片
                }
            }
            m_type = p->type;
            m_time = time;

            //插入时间,底色改为绿色，边框设置右边圆形
            if(p->TimeIcon)
            {
                p->TimeIcon->setStyleSheet("border-top-right-radius:7px;border-bottom-right-radius :7px;border-image:url("");background-color: rgb(91,229,107);color:#ffffff;font: bold 16px");
                p->TimeIcon->setAlignment(Qt::AlignVCenter|Qt::AlignLeft);//靠左对齐
                if(0 != time)
                {
                    char buf[1024] = {0};
                    snprintf(buf, sizeof(buf),"%d\" ",time);
                    p->TimeIcon->setText(buf);
                }
                p->TimeIcon->setGeometry(p->ASRIcon->x()+p->ASRIcon->width(),p->HeadIcon->y(),ColumnWidth_Head_ASR,ColumnWidth_Head_ASR);
            }
            else
            {
               ret = -1;
               break;
            }

            //自动调整行高
            if(p->TextEdit)
            {
                p->TextEdit->setGeometry(p->ASRIcon->x(),p->ASRIcon->y()+p->ASRIcon->height()+2,(ui->widget->width()-ColumnWidth_Head_ASR*4)/6,ColumnWidth_Head_ASR);
                QString QtextContent = QString::fromStdString(textContent);
                p->TextEdit->setText(QtextContent);
                p->TextEdit->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
                p->TextEdit->setStyleSheet("border-radius:7px;border-image:url("");background-color: rgb(255,255,255)");
                p->TextEdit->setWordWrap(true);
                p->TextEdit->adjustSize();
            }
            else
            {
               ret = -1;
               break;
            }

            if(0 != time)
            {
                Interruptplay(m_type);
                m_state = Waiting;
                SwitchGifState(m_state);
                if(this->IsLowPerformance())
                {
                    RobotGif();   //低性能情况下，只贴一张静态图片
                }
                m_CurrentPosition = m_CurrentPosition + p->HeadIcon->height() + p->TextEdit->height();
            }
        }
        else
        {
            switch (ASRTimer) {
            case ASRstart:
            {
                //如果TTS未结束播放，则需要打断。
                if(PlayComplete == false)
                {
                    Interruptplay(m_type);
                }
                //插入用户头像
                if(p->HeadIcon)
                {
                    p->HeadIcon->setStyleSheet("border-image: url(:/image/我.png)");
                    p->HeadIcon->setGeometry (widget_x + widget_width - ColumnWidth_Edge - ColumnWidth_Head_ASR, m_CurrentPosition+ColumnWidth_Edge, ColumnWidth_Head_ASR, ColumnWidth_Head_ASR);
                }
                else
                {
                   ret = -1;
                   break;
                }
                //ASR小喇叭图标，底色改为绿色，边框设置右边圆形，开启定时器
                if(p->ASRIcon)
                {
                    p->ASRIcon->setStyleSheet("border-top-right-radius:7px;border-bottom-right-radius :7px;border-image:url("");background-color: rgb(91,229,107)");
                    p->ASRIcon->setGeometry(p->HeadIcon->x() - 2 - ColumnWidth_Head_ASR,p->HeadIcon->y(),ColumnWidth_Head_ASR,ColumnWidth_Head_ASR);
                    m_giflabelASR = p->ASRIcon;
                }
                else
                {
                   ret = -1;
                   break;
                }
                if(p->type)
                {
                    m_type = p->type;
                }
                else
                {
                   ret = -1;
                   break;
                }
                //插入时间,底色改为绿色，边框设左边圆形
                if(p->TimeIcon)
                {
                    p->TimeIcon->setStyleSheet("border-top-left-radius:7px;border-bottom-left-radius :7px;border-image:url("");background-color: rgb(91,229,107);color:#ffffff;font: bold 16px");
                    p->TimeIcon->setAlignment(Qt::AlignVCenter|Qt::AlignRight);//靠右对齐
                    p->TimeIcon->setGeometry(p->ASRIcon->x() - ColumnWidth_Head_ASR,p->HeadIcon->y(),ColumnWidth_Head_ASR,ColumnWidth_Head_ASR);
                }
                else
                {
                   ret = -1;
                   break;
                }
                m_labelUserRecordtime = p->TimeIcon;
                m_timerUserRecord->start(1000);//刷新显示的时间
                //将小喇叭刷新为第四个图标
                m_Playgifname_User = 4;
                m_timerPlay_User->start(GifSpace);//刷新小喇叭图标
                m_state = InUserVoice;
                SwitchGifState(m_state);//上方标题更改
                if(p->TextEdit)
                {
                    p->TextEdit->setAlignment(Qt::AlignRight | Qt::AlignVCenter);//处理格式，后续不用重复处理
                    p->TextEdit->setStyleSheet("border-radius:7px;border-image:url("");background-color: rgb(255,255,255)");//处理格式，后续不用重复处理
                    //自动调整行高
                    p->TextEdit->setGeometry(p->ASRIcon->x(),p->ASRIcon->y()+p->ASRIcon->height()+2,(ui->widget->width()-ColumnWidth_Head_ASR*4)/6,20);
                    //显示文本内容
                    QString QtextContent = QString::fromStdString(textContent);
                    p->TextEdit->setText(QtextContent);
                    p->TextEdit->setWordWrap(true);
                    p->TextEdit->adjustSize();
                    //再次设置X轴的起始位置
                    p->TextEdit->setGeometry(p->ASRIcon->x() + p->ASRIcon->width() - p->TextEdit->width(),p->ASRIcon->y()+p->ASRIcon->height()+2,p->TextEdit->width(),p->TextEdit->height());

                }
                else
                {
                   ret = -1;
                   break;
                }
                break;
            }
            case ASRRuning:
            {
                //显示文本内容
                if(p->TextEdit)
                {
                    p->TextEdit->setGeometry(p->ASRIcon->x() + p->ASRIcon->width() - p->TextEdit->width(),p->ASRIcon->y()+p->ASRIcon->height()+2,p->TextEdit->width(),p->TextEdit->height());               QString QtextContent = QString::fromStdString(textContent);
                    p->TextEdit->setText(QtextContent);
                    //p->TextEdit->setWordWrap(true);
                    p->TextEdit->adjustSize();
                    //再次设置X轴的起始位置
                    p->TextEdit->setGeometry(p->ASRIcon->x() + p->ASRIcon->width() - p->TextEdit->width(),p->ASRIcon->y()+p->ASRIcon->height()+2,p->TextEdit->width(),p->TextEdit->height());
                }
                else
                {
                   ret = -1;
                   break;
                }
                break;
            }
            case ASRStop:
            {

                m_timerUserRecord->stop();//停止刷新显示的时间
                m_timeUserRecordtime = 0;
                m_timerPlay_User->stop();//停止刷新小喇叭图标
                m_state = Waiting;
                SwitchGifState(m_state);//上方标题更改
                //将小喇叭刷新为暂停图标
                m_Playgifname_User =6;
                QString CSS;
                CSS.sprintf("border-top-right-radius:7px;border-bottom-right-radius :7px;border-image:url(:/image/%d.png);background-color: rgb(91,229,107)",m_Playgifname_User);
                if(m_giflabelASR)
                {
                    m_giflabelASR->setStyleSheet(CSS);
                }
                m_giflabelASR = nullptr;
                PlayComplete = true;

                if(p->TextEdit)
                {
                    p->TextEdit->setGeometry(p->ASRIcon->x() + p->ASRIcon->width() - p->TextEdit->width(),p->ASRIcon->y()+p->ASRIcon->height()+2,p->TextEdit->width(),p->TextEdit->height());
                    QString QtextContent = QString::fromStdString(textContent);
                    p->TextEdit->setText(QtextContent);
                    p->TextEdit->adjustSize();
                    p->TextEdit->setGeometry(p->ASRIcon->x() + p->ASRIcon->width() - p->TextEdit->width(),p->ASRIcon->y()+p->ASRIcon->height()+2,p->TextEdit->width(),p->TextEdit->height());
                }
                else
                {
                   ret = -1;
                   break;
                }
                m_CurrentPosition = m_CurrentPosition + p->HeadIcon->height() + p->TextEdit->height();
                break;
            }
            case ASRComplete:
            {
                //如果TTS未结束播放，则需要打断。
                if(PlayComplete == false)
                {
                    Interruptplay(m_type);
                }
                //插入用户头像
                if(p->HeadIcon)
                {
                    p->HeadIcon->setStyleSheet("border-image: url(:/image/我.png)");
                    p->HeadIcon->setGeometry (widget_x + widget_width - ColumnWidth_Edge - ColumnWidth_Head_ASR, m_CurrentPosition + ColumnWidth_Edge, ColumnWidth_Head_ASR, ColumnWidth_Head_ASR);

                }
                else
                {
                   ret = -1;
                   break;
                }
                //ASR小喇叭图标，底色改为绿色，边框设置右边圆形
                if(p->ASRIcon)
                {
                    p->ASRIcon->setStyleSheet("border-top-right-radius:7px;border-bottom-right-radius :7px;border-image:url("");background-color: rgb(91,229,107)");
                    p->ASRIcon->setGeometry(p->HeadIcon->x() - 2 - ColumnWidth_Head_ASR,p->HeadIcon->y(),ColumnWidth_Head_ASR,ColumnWidth_Head_ASR);
                    m_giflabelASR = p->ASRIcon;
                }
                else
                {
                   ret = -1;
                   break;
                }

                if(p->type)
                {
                    m_type = p->type;
                }
                else
                {
                   ret = -1;
                   break;
                }
                //插入时间,底色改为绿色，边框设左边圆形
                if(p->TimeIcon)
                {
                    p->TimeIcon->setStyleSheet("border-top-left-radius:7px;border-bottom-left-radius :7px;border-image:url("");background-color: rgb(91,229,107);color:#ffffff;font: bold 16px");
                    p->TimeIcon->setAlignment(Qt::AlignVCenter|Qt::AlignRight);//靠右对齐
                    //直接显示时间，不需要启动定时器
                    char buf[1024] = {0};
                    snprintf(buf, sizeof(buf),"%d\" ",time);
                    p->TimeIcon->setText(buf);
                    p->TimeIcon->setGeometry(p->ASRIcon->x() - ColumnWidth_Head_ASR,p->HeadIcon->y(),ColumnWidth_Head_ASR,ColumnWidth_Head_ASR);

                }
                else
                {
                   ret = -1;
                   break;
                }

                //小喇叭直接刷新为第六个图标
                m_Playgifname_User = 6;
                Inplay_User();
                m_timerPlay_User->stop();//停止刷新小喇叭的定时器，避免之前开始有调用start
                m_timerUserRecord->stop();//停止刷新时间的定时器，避免之前开始有调用start

                m_state = InUserVoice;
                SwitchGifState(m_state);//上方标题更改
                if(p->TextEdit)
                {
                    p->TextEdit->setAlignment(Qt::AlignRight | Qt::AlignVCenter);//处理格式，后续不用重复处理
                    p->TextEdit->setStyleSheet("border-radius:7px;border-image:url("");background-color: rgb(255,255,255)");//处理格式，后续不用重复处理
                    //自动调整行高
                    p->TextEdit->setGeometry(p->ASRIcon->x(),p->ASRIcon->y()+p->ASRIcon->height()+2,(ui->widget->width()-ColumnWidth_Head_ASR*4)/6,20);

                    //显示文本内容
                    QString QtextContent = QString::fromStdString(textContent);
                    p->TextEdit->setText(QtextContent);
                    p->TextEdit->setWordWrap(true);
                    p->TextEdit->adjustSize();

                    //再次设置X轴的起始位置
                    p->TextEdit->setGeometry(p->ASRIcon->x() + p->ASRIcon->width() - p->TextEdit->width(),p->ASRIcon->y()+p->ASRIcon->height()+2,p->TextEdit->width(),p->TextEdit->height());
                }
                else
                {
                   ret = -1;
                   break;
                }
                    m_CurrentPosition = m_CurrentPosition + p->HeadIcon->height() + p->TextEdit->height();
                break;
            }
            default:
                break;
            }
            qApp->processEvents();
        }
        //全部控件刷新显示
        if(p)
        {
            if(p->HeadIcon)
                p->HeadIcon->show();
            if(p->ASRIcon)
                p->ASRIcon->show();
            if(p->TimeIcon)
                p->TimeIcon->show();
            if(p->TextEdit)
                p->TextEdit->show();
        }
        else
        {
           ret = -1;
           break;
        }
    }while(false);

    m_ShowContentRunningNum-= 1;

    return ret;
}


int AIRobotWindow::Interruptplay(AIMESSAGETYPE type)
{    if(AI_Robot == type)
    {
        QString CSS;
        m_timerPlay_Robbt->stop();
        time_num_robot = 0;
        m_Playgifname_robot =3;
        CSS.sprintf(":/image/%d.png",m_Playgifname_robot);
        QPixmap bgImage(CSS);
        if(m_giflabelASR)
        {
            m_giflabelASR->setPixmap(bgImage.scaled(QSize(m_giflabelASR->width()-20,m_giflabelASR->height()-20), Qt::IgnoreAspectRatio, Qt::SmoothTransformation));
            m_giflabelASR->setAlignment(Qt::AlignCenter);
        }
        m_giflabelASR = nullptr;
        PlayComplete = true;
    }
    else
    {
        QString CSS;
        m_timerPlay_User->stop();
        m_Playgifname_User =6;
        CSS.sprintf(":/image/%d.png",m_Playgifname_User);
        QPixmap bgImage(CSS);
        if(m_giflabelASR)
        {
            //m_giflabelASR->setStyleSheet(CSS);
            m_giflabelASR->setPixmap(bgImage.scaled(QSize(m_giflabelASR->width()-20,m_giflabelASR->height()-20), Qt::IgnoreAspectRatio, Qt::SmoothTransformation));
            m_giflabelASR->setAlignment(Qt::AlignCenter);
        }
        m_giflabelASR = nullptr;
        PlayComplete = true;
        m_timerUserRecord->stop();//停止刷新显示的时间
        m_timeUserRecordtime = 0;
    }
    return 0;
}


int AIRobotWindow::Inplay_Robot()
{
    QString CSS;
    CSS.sprintf(":/image/%d.png",m_Playgifname_robot);

    QPixmap bgImage(CSS);
    if(m_giflabelASR)
    {
        m_giflabelASR->setPixmap(bgImage.scaled(QSize(m_giflabelASR->width()-20,m_giflabelASR->height()-20), Qt::IgnoreAspectRatio, Qt::SmoothTransformation));
        m_giflabelASR->setAlignment(Qt::AlignCenter);
    }
    m_Playgifname_robot++;
    if(m_Playgifname_robot == 4)
    {
        m_Playgifname_robot = 1;
    }
    return 0;
}

int AIRobotWindow::Inplay_User()
{
    QString CSS;
    CSS.sprintf(":/image/%d.png",m_Playgifname_User);
    QPixmap bgImage(CSS);
    if(m_giflabelASR)
    {
        m_giflabelASR->setPixmap(bgImage.scaled(QSize(m_giflabelASR->width()-20,m_giflabelASR->height()-20), Qt::IgnoreAspectRatio, Qt::SmoothTransformation));
        m_giflabelASR->setAlignment(Qt::AlignCenter);
    }
    m_Playgifname_User++;
    if(m_Playgifname_User == 7)
    {
        m_Playgifname_User = 4;
    }

    return 0;
}


int AIRobotWindow::clearAIObject()
{
    if(AIObjectVector.size() == 0)
    {
        return 0;
    }

    for(int i = 0; i<AIObjectVector.size();i++)
    {
        AIObject * p = AIObjectVector[i];
        if(p->ASRIcon)
        {
            delete p->ASRIcon;
            p->ASRIcon = nullptr;
        }
        if(p->HeadIcon)
        {
            delete p->HeadIcon;
            p->HeadIcon = nullptr;
        }
        if(p->TextEdit)
        {
            delete p->TextEdit;
            p->TextEdit = nullptr;
        }
        if(p->TimeIcon)
        {
            delete p->TimeIcon;
            p->TimeIcon = nullptr;
        }
        if(p)
        {
            delete p;
            p = nullptr;
        }
    }
    AIObjectVector.clear();
    return 0;
}

int AIRobotWindow::RobotGif()
{
    QString CSS;
    int ret = 0;
    switch (m_state) {
    case RobotBroadcasting:
    {
        CSS.sprintf("border-image:url(:/image/playing/%d.png)",m_timer_gif_num);
        ret = 1;
        break;
    }
    case Waiting:
    {
        CSS.sprintf("border-image:url(:/image/waiting/%d.png)",m_timer_gif_num);
        ret = 1;
        break;
    }
    case InUserVoice:
    {
        CSS.sprintf("border-image:url(:/image/recording/%d.png)",m_timer_gif_num);
        ret = 1;
        break;
    }
    default:{

        break;
    }
    }
    if(ret == 1)
    {
        if(ui->LableRobot)
        {
            ui->LableRobot->setStyleSheet(CSS);
        }
        m_timer_gif_num++;
        if(10100 == m_timer_gif_num)
            m_timer_gif_num = 10000;
    }

    return 0;
}

int AIRobotWindow::UpdateUserRecordtime()
{
    m_timeUserRecordtime++;
    char buf[1024] = {0};
    snprintf(buf, sizeof(buf),"%d\" ",m_timeUserRecordtime);
    m_labelUserRecordtime->setText(buf);
    return 0;
}



int AIRobotWindow::SwitchGifState(int state)
{
    switch (state) {
    case RobotBroadcasting:{
        ui->label->setText("机器人安妮播报中");
        break;
    }
    case Waiting:{
        ui->label->setText("机器人安妮等待中");
        break;
    }
    case InUserVoice:{
        ui->label->setText("用户语音中");
        break;
    }
    default:{
        break;
    }
    }
    //设置字体
    if(ui->label)
    {
        ui->label->setAlignment(Qt::AlignCenter);
        ui->label->setStyleSheet("color: rgb(0, 85, 255);font: 75 25pt;");
    }
    return 0;
}



bool AIRobotWindow::initLowPerformance()
{
#ifdef WIN32
    return false;
#else
    return true;
#endif

}
